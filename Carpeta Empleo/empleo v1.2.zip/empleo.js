/* HERO PARALLAX */
(function() {
  var hero = document.getElementById('hero');
  var content = hero.querySelector('.hero-content');
  var right = hero.querySelector('.hero-right');
  var scrollCue = hero.querySelector('.hero-scroll');
  var orbs = hero.querySelectorAll('.orb');
  var grid = hero.querySelector('.hero-grid');

  function onScroll() {
    var sy = window.pageYOffset;
    var hh = hero.offsetHeight;
    var p  = Math.min(sy / (hh * 0.4), 1);
    var fade = Math.max(0, 1 - p * 1.6);
    var moveY = p * -48;
    if (content) { content.style.opacity = fade; content.style.transform = 'translateY(' + moveY + 'px)'; }
    if (right)   { right.style.opacity = fade; right.style.transform = 'translate(0, calc(-50% + ' + (moveY * 0.6) + 'px))'; }
    if (scrollCue) { scrollCue.style.opacity = Math.max(0, 1 - p * 4); }
    orbs.forEach(function(o) { o.style.opacity = Math.max(0, 1 - p * 2.2); });
    if (grid) { grid.style.opacity = Math.max(0.15, 1 - p * 1.3); }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
})();

/* SCROLL REVEAL */
(function() {
  var els = document.querySelectorAll('.reveal');
  if (!els.length) return;
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var siblings = Array.prototype.slice.call(entry.target.parentElement.querySelectorAll('.reveal:not(.visible)'));
        var idx = siblings.indexOf(entry.target);
        setTimeout(function() { entry.target.classList.add('visible'); }, idx * 65);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });
  els.forEach(function(el) { observer.observe(el); });
})();

/* SMOOTH SCROLL */
(function() {
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var id = a.getAttribute('href');
      if (id === '#') return;
      var target = document.querySelector(id);
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
  });
})();
