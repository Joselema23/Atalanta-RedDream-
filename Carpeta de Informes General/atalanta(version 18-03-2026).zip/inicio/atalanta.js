// --- 1. Slider ---
const slides = document.querySelectorAll(".slide");
const next = document.querySelector(".next");
const prev = document.querySelector(".prev");
const sliderDots = document.querySelectorAll(".dot-nav");
const menuBtn = document.getElementById("menu-btn");
const navLinks = document.querySelector(".nav-links");
const tarjetas = document.querySelectorAll('.tarjeta');


let index = 0;
const slideDuration = 5000;

// Función para actualizar los dots
function updateDots(currentIndex) {
    sliderDots.forEach((dot, i) => {
        dot.classList.toggle('active', i === currentIndex);
    });
}



tarjetas.forEach(tarjeta => {
  tarjeta.addEventListener('mousemove', e => {
    const rect = tarjeta.getBoundingClientRect();
    tarjeta.style.setProperty('--x', `${e.clientX - rect.left}px`);
    tarjeta.style.setProperty('--y', `${e.clientY - rect.top}px`);
  });
});

document.addEventListener('DOMContentLoaded', function() {
    const menuBtn = document.getElementById('menu-btn');
    const navLinks = document.getElementById('nav-links');
    const navLinkItems = document.querySelectorAll('.nav-links a');

    if (!menuBtn || !navLinks) {
        console.error('❌ Elementos del menú no encontrados');
        return;
    }

    console.log('✅ Menú hamburger inicializado');

    // ABRIR/CERRAR MENÚ AL HACER CLIC EN BOTÓN
    menuBtn.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        navLinks.classList.toggle('active');
        menuBtn.classList.toggle('active');
        document.body.classList.toggle('menu-open');
        
        console.log('Menú toggled');
    });

    // CERRAR MENÚ AL HACER CLIC EN UN ENLACE
    navLinkItems.forEach(link => {
        link.addEventListener('click', function() {
            navLinks.classList.remove('active');
            menuBtn.classList.remove('active');
            document.body.classList.remove('menu-open');
        });
    });

    // CERRAR MENÚ AL HACER CLIC FUERA
    document.addEventListener('click', function(event) {
        const isMenuBtn = event.target.closest('.menu-btn');
        const isNavLinks = event.target.closest('.nav-links');
        
        if (!isMenuBtn && !isNavLinks && navLinks.classList.contains('active')) {
            navLinks.classList.remove('active');
            menuBtn.classList.remove('active');
            document.body.classList.remove('menu-open');
        }
    });

    // CERRAR MENÚ CON ESC
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' && navLinks.classList.contains('active')) {
            navLinks.classList.remove('active');
            menuBtn.classList.remove('active');
            document.body.classList.remove('menu-open');
        }
    });
});

function showSlide(i){
    slides.forEach(slide => slide.classList.remove("active"));
    slides[i].classList.add("active");
    
    // Actualizar los dots
    updateDots(i);
}
if(next){
    next.addEventListener("click", () => {
        index++;
        if(index >= slides.length){
            index = 0;
        }
        showSlide(index);
    });
}

if(prev){
    prev.addEventListener("click", () => {
        index--;
        if(index < 0){
            index = slides.length - 1;
        }
        showSlide(index);
    });
}


document.addEventListener('mousemove', e => {
    document.querySelector('.background').style.transform = `translate(${e.clientX/100}px, ${e.clientY/100}px)`;
});

// Agregar click a los dots para navegar
sliderDots.forEach((dot, i) => {
    dot.addEventListener("click", () => {
        index = i;
        showSlide(index);
    });
});

// Iniciar el slider
showSlide(index);

setInterval(() => {
    index++;
    if(index >= slides.length){
        index = 0;
    }
    showSlide(index);
}, slideDuration);

// --- 2. Animación de números contadores ---
function animateNumber(element, target, duration = 2000) {
    const start = 1;
    const startTime = performance.now();
    
    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Función de easing
        const easeOut = 1 - Math.pow(1 - progress, 3);
        
        const current = Math.floor(start + (target - start) * easeOut);
        element.textContent = current;
        
        if (progress < 1) {
            requestAnimationFrame(update);
        } else {
            element.textContent = target;
        }
    }
    
    requestAnimationFrame(update);
}












// Observer para detectar cuando los números son visibles
const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.5
};

const numberObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const target = parseInt(entry.target.getAttribute('data-target'));
            if (!isNaN(target)) {
                animateNumber(entry.target, target, 2500);
            }
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observar todos los elementos con la clase stat-card h3
document.querySelectorAll('.stat-card h3').forEach(el => {
    numberObserver.observe(el);
});

// --- 2. Initial Reveal Animations ---
// Las animaciones fade-in las gestiona el CSS con animation-fill-mode: both
// No es necesario añadir la clase .visible manualmente

// --- 3. Navbar Glass Effect on Scroll ---
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }
});

// --- 4. Scroll Animations (Intersection Observer) ---
const fadeObserverOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
};

const fadeObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, fadeObserverOptions);

document.querySelectorAll('.fade-up').forEach(el => {
    fadeObserver.observe(el);
});

// --- 5. Interactive Gradient Background ---
const interBubble = document.querySelector('.interactive');

if (interBubble) {

    let curX = 0;
    let curY = 0;
    let tgX = 0;
    let tgY = 0;

    function move() {
        curX += (tgX - curX) / 20;
        curY += (tgY - curY) / 20;

        interBubble.style.transform =
            `translate(${Math.round(curX)}px, ${Math.round(curY)}px)`;

        requestAnimationFrame(move);
    }

    window.addEventListener('mousemove', (event) => {
        tgX = event.clientX;
        tgY = event.clientY;

        if (interBubble.style.opacity === '0') {
            interBubble.style.opacity = '1';
        }
    });

    move();
}

// --- 6. Bento Cards Hover Effect ---
document.querySelectorAll('.bento-card').forEach(card => {

    card.addEventListener('mousemove', e => {

        const rect = card.getBoundingClientRect();

        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        card.style.setProperty('--mouse-x', `${x}px`);
        card.style.setProperty('--mouse-y', `${y}px`);

    });

});



// --- 7. Contact Form ---
const form = document.getElementById('contactForm');
const submitBtn = document.getElementById('submitBtn');
const formMessage = document.getElementById('formMessage');

if (form) {

    form.addEventListener('submit', (e) => {

        e.preventDefault();

        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        formMessage.textContent = '';
        formMessage.className = 'form-message';

        setTimeout(() => {

            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;

            formMessage.textContent =
                '¡Mensaje enviado correctamente! Nos pondremos en contacto pronto.';

            formMessage.classList.add('msg-success');

            form.reset();

            setTimeout(() => {
                formMessage.textContent = '';
            }, 5000);

        }, 1500);

    });

}



