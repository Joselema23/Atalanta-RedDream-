/* ═══════════════════════════════════════════════════
   ATALANTA — main.js
   ═══════════════════════════════════════════════════ */

/* ── MENÚ MÓVIL ──────────────────────────────────── */
function toggleMenu() {
  document.getElementById('mob').classList.toggle('open');
}

/* ── CANVAS LLUVIA DE CÓDIGO ─────────────────────── */
(function () {
  const c = document.getElementById('code-canvas');
  if (!c) return;
  const ctx = c.getContext('2d');
  const chars = '01{}[];()=><!-/abcdefABCDEF#$%&*';
  const fs = 13;
  let W, H, drops;

  function init() {
    W = c.width = window.innerWidth;
    H = c.height = window.innerHeight;
    const cols = Math.floor(W / fs);
    drops = Array.from({ length: cols }, () => Math.random() * -80);
  }

  function draw() {
    ctx.fillStyle = 'rgba(17,17,17,0.065)';
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = '#dc0630';
    ctx.font = fs + 'px JetBrains Mono, monospace';
    drops.forEach((y, i) => {
      ctx.fillText(chars[Math.floor(Math.random() * chars.length)], i * fs, y * fs);
      if (y * fs > H && Math.random() > 0.975) drops[i] = 0;
      drops[i] += 0.35;
    });
  }

  init();
  setInterval(draw, 65);
  window.addEventListener('resize', init);
})();

/* ── SCROLL ANIMACIONES (fade-up) ────────────────── */
const observer = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) e.target.classList.add('visible');
  });
}, { threshold: 0.08 });

document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));

/* ── NAV SCROLL ──────────────────────────────────── */
window.addEventListener('scroll', () => {
  document.getElementById('nav').classList.toggle('scrolled', window.scrollY > 40);
});

/* ── FORM SUBMIT ─────────────────────────────────── */
function handleSubmit(e) {
  e.preventDefault();
  const btn = document.getElementById('submit-btn');
  btn.textContent = '✓ ENVIADO — TE CONTACTAMOS EN MENOS DE 24H';
  btn.classList.add('done');
  btn.disabled = true;
}
