(function() {
  var hero      = document.getElementById('hero');
  if (!hero) return;
  var content   = hero.querySelector('.hero-content');
  var right     = hero.querySelector('.hero-right');
  var scrollCue = hero.querySelector('.hero-scroll');
  var features  = hero.querySelector('.hero-features');
  var orbs      = hero.querySelectorAll('.orb');
  var grid      = hero.querySelector('.hero-grid');

  // Inicializar features igual que el resto: invisible, luego aparece
  if (features) {
    features.style.opacity   = '0';
    features.style.transform = 'translateX(-50%) translateY(24px)';
    setTimeout(function() {
      features.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
      features.style.opacity    = '1';
      features.style.transform  = 'translateX(-50%) translateY(0)';
      setTimeout(function() {
        features.style.transition = '';
      }, 650);
    }, 1200);
  }

  function onScroll() {
    var sy = window.pageYOffset;
    var hh = hero.offsetHeight;
    // p llega a 1 solo cuando has scrolleado la altura COMPLETA del hero
    // El fade empieza solo después del 60% del recorrido
    var p = Math.min(sy / hh, 1);
    var pDelayed = Math.max(0, (p - 0.6) / 0.4); // 0→1 solo en el último 40%

    var fade  = Math.max(0, 1 - pDelayed * 2.2);
    var moveY = pDelayed * -40;

    // Feature bar: empieza aún más tarde, en el 80%
    var pFeat    = Math.max(0, (p - 0.80) / 0.2);
    var fadeFeat = Math.max(0, 1 - pFeat * 2.5);
    var moveYFeat = pDelayed * -14;

    if (content) {
      content.style.opacity   = fade;
      content.style.transform = 'translateY(' + moveY + 'px)';
    }
    if (right) {
      right.style.opacity   = fade;
      right.style.transform = 'translate(0, calc(-50% + ' + (moveY * 0.6) + 'px))';
    }
    if (features) {
      features.style.opacity   = fadeFeat;
      features.style.transform = 'translateX(-50%) translateY(' + moveYFeat + 'px)';
    }
    if (scrollCue) {
      scrollCue.style.opacity = Math.max(0, 1 - p * 4);
    }
    orbs.forEach(function(o) {
      o.style.opacity = Math.max(0, 1 - p * 2.2);
    });
    if (grid) {
      grid.style.opacity = Math.max(0.15, 1 - p * 1.3);
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
})();

/* ═══════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════ */
(function() {
  var els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var siblings = Array.prototype.slice.call(
          entry.target.parentElement.querySelectorAll('.reveal:not(.visible)')
        );
        var idx = siblings.indexOf(entry.target);
        setTimeout(function() {
          entry.target.classList.add('visible');
        }, idx * 65);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });

  els.forEach(function(el) { observer.observe(el); });
})();

/* ═══════════════════════════════════════════
   CAROUSEL — pause / resume
═══════════════════════════════════════════ */
(function() {
  var wrapper = document.getElementById('carouselWrapper');
  var btn     = document.getElementById('carouselBtn');
  var status  = document.getElementById('carouselStatus');
  var paused  = false;

  if (!btn || !wrapper) return;

  btn.addEventListener('click', function() {
    paused = !paused;
    if (paused) {
      wrapper.classList.add('carousel-paused');
      btn.textContent    = '▶';
      status.textContent = 'Pausado — Click para reanudar';
    } else {
      wrapper.classList.remove('carousel-paused');
      btn.textContent    = '⏸';
      status.textContent = 'Hover para pausar · Click para detener';
    }
  });
})();

/* ═══════════════════════════════════════════
   SMOOTH SCROLL — all anchor links
═══════════════════════════════════════════ */
(function() {
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var id = a.getAttribute('href');
      if (id === '#') return;
      var target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        var navHeight = 68;
        var top = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    });
  });
})();

/* ═══════════════════════════════════════════
   COUNTER ANIMATION — metrics
═══════════════════════════════════════════ */
(function() {
  var counters = document.querySelectorAll('.metric-num');
  if (!counters.length) return;
  var done = false;

  // Store original values BEFORE any DOM manipulation
  var targets = [];
  counters.forEach(function(el) {
    var unit     = el.querySelector('.unit');
    var unitText = unit ? unit.textContent : '';
    var rawText  = el.textContent.replace(unitText, '').trim();
    var isFloat  = rawText.indexOf(',') !== -1 || rawText.indexOf('.') !== -1;
    var target   = parseFloat(rawText.replace(',', '.'));
    targets.push({ el: el, unitText: unitText, isFloat: isFloat, target: target });
  });

  var obs = new IntersectionObserver(function(entries) {
    if (done) return;
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        done = true;
        targets.forEach(function(item) {
          if (isNaN(item.target)) return;

          var start     = 0;
          var duration  = 1600;
          var startTime = null;

          function step(ts) {
            if (!startTime) startTime = ts;
            var progress = Math.min((ts - startTime) / duration, 1);
            var ease     = 1 - Math.pow(1 - progress, 3);
            var current  = start + (item.target - start) * ease;
            var display  = item.isFloat
              ? current.toFixed(2).replace('.', ',')
              : Math.round(current).toString();

            if (item.unitText) {
              item.el.innerHTML = display + '<span class="unit">' + item.unitText + '</span>';
            } else {
              item.el.textContent = display;
            }
            if (progress < 1) requestAnimationFrame(step);
          }
          requestAnimationFrame(step);
        });
        obs.disconnect();
      }
    });
  }, { threshold: 0.3 });

  var firstMetric = document.querySelector('.metric-box');
  if (firstMetric) obs.observe(firstMetric);
})();

/* ═══════════════════════════════════════════
   FORM — basic validation + feedback
═══════════════════════════════════════════ */
(function() {
  var btn = document.querySelector('.form-submit');
  if (!btn) return;

  btn.addEventListener('click', function() {
    var email    = document.querySelector('input[type="email"]');
    var checkbox = document.querySelector('.form-check input[type="checkbox"]');

    if (email && !email.value.trim()) {
      email.focus();
      email.style.borderColor = 'rgba(220,6,48,0.8)';
      setTimeout(function() { email.style.borderColor = ''; }, 2000);
      return;
    }
    if (checkbox && !checkbox.checked) {
      checkbox.parentElement.style.outline = '1px solid rgba(220,6,48,0.6)';
      checkbox.parentElement.style.borderRadius = '4px';
      setTimeout(function() { checkbox.parentElement.style.outline = ''; }, 2000);
      return;
    }

    var original = btn.innerHTML;
    btn.innerHTML = '✓ Solicitud enviada correctamente';
    btn.style.background = '#16a34a';
    btn.disabled = true;
    setTimeout(function() {
      btn.innerHTML = original;
      btn.style.background = '';
      btn.disabled = false;
    }, 3500);
  });
})();

/* ═══════════════════════════════════════════
   NAV — highlight active section on scroll
═══════════════════════════════════════════ */
(function() {
  var sections = document.querySelectorAll('section[id]');
  var navLinks = document.querySelectorAll('.nav-links a');
  if (!navLinks.length || !sections.length) return;

  function onScroll() {
    var scrollY = window.pageYOffset + 120;
    sections.forEach(function(sec) {
      if (scrollY >= sec.offsetTop && scrollY < sec.offsetTop + sec.offsetHeight) {
        navLinks.forEach(function(a) {
          a.classList.remove('active');
          if (a.getAttribute('href') === '#' + sec.id) {
            a.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
})();


/* ═══════════════════════════════════════════
   HAMBURGER MENU
═══════════════════════════════════════════ */
(function() {
  var btn = document.getElementById('hamburgerBtn');
  var nav = document.getElementById('mobileNav');
  if (!btn || !nav) return;
  btn.addEventListener('click', function() {
        btn.classList.toggle('open');
    nav.classList.toggle('open');
  });
  nav.querySelectorAll('a').forEach(function(a) {
    a.addEventListener('click', function() {
      btn.classList.remove('open');
      nav.classList.remove('open');
    });
  });
})();

/* ═══════════════════════════════════════════
   INTRO BAND — entra izquierda / sale derecha, indefinidamente
═══════════════════════════════════════════ */
(function() {
  var band = document.getElementById('introBand');
  if (!band) return;
  var p = band.querySelector('p');
  if (!p) return;

  var state = 'left'; // 'left' | 'visible' | 'right'

  function go(newState) {
    if (state === newState) return;
    state = newState;

    if (newState === 'left') {
      // Reset instantáneo a izquierda — sin transición
      p.classList.remove('intro-enter', 'intro-leave');
      void p.offsetWidth; // reflow
    } else if (newState === 'visible') {
      // Entra desde la izquierda
      p.classList.remove('intro-leave');
      void p.offsetWidth;
      p.classList.add('intro-enter');
    } else if (newState === 'right') {
      // Sale hacia la derecha
      p.classList.remove('intro-enter');
      void p.offsetWidth;
      p.classList.add('intro-leave');
    }
  }

  function onScroll() {
    var rect = band.getBoundingClientRect();
    var wh   = window.innerHeight;

    if (rect.top < wh * 0.7 && rect.bottom > wh * 0.1) {
      // La sección está en pantalla
      go('visible');
    } else if (rect.bottom <= wh * 0.1) {
      // Salió por arriba → sale por la derecha, luego reset a izquierda
      if (state === 'visible') go('right');
      // Tras un momento, resetear para que pueda volver a entrar
      setTimeout(function() {
        if (state === 'right') go('left');
      }, 500);
    } else {
      // No está en pantalla (está por debajo) → reset a izquierda sin animación
      if (state !== 'left') go('left');
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // check on load
})();
