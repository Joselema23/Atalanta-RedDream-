<?php
// ============================================================
//  auth_login.php — Endpoint de autenticación
//  Ruta: gestor de incidencias1/auth_login.php
//  Método: POST (JSON)
// ============================================================

require_once 'config.php';

// --- Solo aceptar POST ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Método no permitido.']));
}

// --- Cabeceras de seguridad ---
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// --- Leer JSON del body ---
$input = json_decode(file_get_contents('php://input'), true);

$email    = trim($input['email']    ?? '');
$password = trim($input['password'] ?? '');

// --- Validación básica de entrada ---
if (empty($email) || empty($password)) {
    exit(json_encode(['success' => false, 'message' => 'Email y contraseña son obligatorios.']));
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    exit(json_encode(['success' => false, 'message' => 'Formato de email no válido.']));
}

// --- Limitar longitudes para evitar ataques de buffer ---
if (strlen($email) > 180 || strlen($password) > 128) {
    exit(json_encode(['success' => false, 'message' => 'Datos no válidos.']));
}

// --- Conexión PDO ---
$pdo = Database::connect();

// ============================================================
//  ANTI BRUTE-FORCE: Comprobar si la IP está bloqueada
// ============================================================
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

// Buscar usuario y comprobar bloqueo
// NOTA: usamos prepared statement — NUNCA concatenar variables en SQL
$stmt = $pdo->prepare(
    "SELECT id, nombre, apellidos, email, password_hash, rol, activo,
            intentos_login, bloqueado_hasta
     FROM users
     WHERE email = :email
     LIMIT 1"
);
$stmt->execute([':email' => $email]);
$user = $stmt->fetch();

// --- Si no existe el usuario, respuesta genérica (evita user enumeration) ---
if (!$user) {
    // Pequeño delay aleatorio para dificultar timing attacks
    usleep(random_int(200000, 400000));
    registrarAudit($pdo, null, 'LOGIN_FAIL', "Email no encontrado: $email", $ip);
    exit(json_encode(['success' => false, 'message' => 'Credenciales incorrectas.']));
}

// --- Comprobar si la cuenta está bloqueada ---
if ($user['bloqueado_hasta'] !== null) {
    $bloqueadoHasta = new DateTime($user['bloqueado_hasta']);
    $ahora          = new DateTime();
    if ($ahora < $bloqueadoHasta) {
        $segundos = $ahora->diff($bloqueadoHasta);
        $minutos  = $segundos->i + ($segundos->h * 60);
        registrarAudit($pdo, $user['id'], 'LOGIN_BLOCKED', "Cuenta bloqueada hasta {$user['bloqueado_hasta']}", $ip);
        exit(json_encode([
            'success' => false,
            'message' => "Cuenta bloqueada por demasiados intentos. Inténtalo en $minutos minuto(s)."
        ]));
    } else {
        // El bloqueo expiró, resetear contadores
        $pdo->prepare("UPDATE users SET intentos_login = 0, bloqueado_hasta = NULL WHERE id = :id")
            ->execute([':id' => $user['id']]);
        $user['intentos_login'] = 0;
    }
}

// --- Comprobar cuenta activa ---
if (!$user['activo']) {
    exit(json_encode(['success' => false, 'message' => 'Cuenta desactivada. Contacta con el administrador.']));
}

// ============================================================
//  VERIFICACIÓN DE CONTRASEÑA con password_verify (bcrypt)
// ============================================================
if (!password_verify($password, $user['password_hash'])) {
    $intentos = $user['intentos_login'] + 1;

    if ($intentos >= MAX_LOGIN_ATTEMPTS) {
        // Bloquear cuenta
        $bloqueadoHasta = date('Y-m-d H:i:s', time() + LOCKOUT_TIME);
        $pdo->prepare(
            "UPDATE users SET intentos_login = :intentos, bloqueado_hasta = :hasta WHERE id = :id"
        )->execute([':intentos' => $intentos, ':hasta' => $bloqueadoHasta, ':id' => $user['id']]);

        registrarAudit($pdo, $user['id'], 'LOGIN_BLOCKED', "Bloqueado tras $intentos intentos", $ip);
        exit(json_encode([
            'success' => false,
            'message' => 'Demasiados intentos fallidos. Cuenta bloqueada 15 minutos.'
        ]));
    }

    // Incrementar contador de intentos
    $pdo->prepare("UPDATE users SET intentos_login = :intentos WHERE id = :id")
        ->execute([':intentos' => $intentos, ':id' => $user['id']]);

    usleep(random_int(200000, 400000));
    registrarAudit($pdo, $user['id'], 'LOGIN_FAIL', "Intento fallido $intentos/" . MAX_LOGIN_ATTEMPTS, $ip);
    exit(json_encode([
        'success' => false,
        'message' => 'Credenciales incorrectas. Intento ' . $intentos . ' de ' . MAX_LOGIN_ATTEMPTS . '.'
    ]));
}

// ============================================================
//  LOGIN CORRECTO — Iniciar sesión segura
// ============================================================

// Resetear intentos fallidos
$pdo->prepare("UPDATE users SET intentos_login = 0, bloqueado_hasta = NULL WHERE id = :id")
    ->execute([':id' => $user['id']]);

// Configurar sesión segura
iniciarSesionSegura();
$_SESSION['user_id']  = $user['id'];
$_SESSION['nombre']   = $user['nombre'];
$_SESSION['email']    = $user['email'];
$_SESSION['rol']      = $user['rol'];
$_SESSION['ip']       = $ip;
$_SESSION['ua']       = $_SERVER['HTTP_USER_AGENT'] ?? '';
$_SESSION['login_at'] = time();

// Regenerar ID de sesión (previene session fixation)
session_regenerate_id(true);

registrarAudit($pdo, $user['id'], 'LOGIN_OK', 'Acceso correcto', $ip);

// Redirigir según rol
$redirect = getRolRedirect($user['rol']);

exit(json_encode([
    'success'  => true,
    'message'  => '¡Bienvenido, ' . htmlspecialchars($user['nombre']) . '!',
    'rol'      => $user['rol'],
    'redirect' => $redirect
]));


// ============================================================
//  FUNCIONES AUXILIARES
// ============================================================

function iniciarSesionSegura(): void {
    ini_set('session.use_strict_mode', 1);
    ini_set('session.cookie_httponly', 1);
    ini_set('session.cookie_samesite', 'Strict');
    // En producción con HTTPS descomentar:
    // ini_set('session.cookie_secure', 1);

    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_start();
}

function getRolRedirect(string $rol): string {
    $rutas = [
        'admin'      => 'dashboard/admin.php',
        'jefe'       => 'dashboard/jefe.php',
        'trabajador' => 'dashboard/trabajador.php',
        'cliente'    => 'dashboard/cliente.php',
    ];
    return $rutas[$rol] ?? 'dashboard/cliente.php';
}

function registrarAudit(PDO $pdo, ?int $userId, string $accion, string $detalle, string $ip): void {
    try {
        $pdo->prepare(
            "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, :accion, :detalle, :ip)"
        )->execute([':uid' => $userId, ':accion' => $accion, ':detalle' => $detalle, ':ip' => $ip]);
    } catch (PDOException $e) {
        error_log('[AUDIT ERROR] ' . $e->getMessage());
    }
}
