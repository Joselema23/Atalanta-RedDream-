<?php
// ============================================================
//  dashboard/admin.php — Panel de Administrador
//  Solo accesible con rol: admin
// ============================================================
require_once '../auth_check.php';
requireRol(['admin']);

$pdo = Database::connect();

// --- Acción: cambiar rol de usuario ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    $action = $_POST['action'];

    // CAMBIAR ROL
    if ($action === 'cambiar_rol') {
        $userId  = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        $nuevoRol = $_POST['rol'] ?? '';

        $rolesValidos = ['cliente', 'trabajador', 'jefe', 'admin'];
        if (!$userId || !in_array($nuevoRol, $rolesValidos, true)) {
            exit(json_encode(['success' => false, 'message' => 'Datos no válidos.']));
        }

        // No permitir que el admin se quite su propio rol
        if ($userId === getUserId()) {
            exit(json_encode(['success' => false, 'message' => 'No puedes modificar tu propio rol.']));
        }

        $stmt = $pdo->prepare("UPDATE users SET rol = :rol WHERE id = :id");
        $stmt->execute([':rol' => $nuevoRol, ':id' => $userId]);

        // Audit log
        $pdo->prepare(
            "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, 'ROLE_CHANGE', :det, :ip)"
        )->execute([
            ':uid' => getUserId(),
            ':det' => "Rol de usuario $userId cambiado a $nuevoRol",
            ':ip'  => $_SERVER['REMOTE_ADDR']
        ]);

        exit(json_encode(['success' => true, 'message' => 'Rol actualizado correctamente.']));
    }

    // ACTIVAR / DESACTIVAR usuario
    if ($action === 'toggle_activo') {
        $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
        if (!$userId || $userId === getUserId()) {
            exit(json_encode(['success' => false, 'message' => 'Operación no permitida.']));
        }

        $pdo->prepare("UPDATE users SET activo = NOT activo WHERE id = :id")->execute([':id' => $userId]);
        exit(json_encode(['success' => true, 'message' => 'Estado del usuario actualizado.']));
    }
}

// --- Obtener todos los usuarios ---
$usuarios = $pdo->query(
    "SELECT id, nombre, apellidos, email, rol, activo, created_at FROM users ORDER BY created_at DESC"
)->fetchAll();

// --- Obtener estadísticas rápidas ---
$stats = $pdo->query(
    "SELECT
        COUNT(*) AS total_tickets,
        SUM(estado = 'abierto')      AS abiertos,
        SUM(estado = 'en_progreso')  AS en_progreso,
        SUM(estado = 'resuelto')     AS resueltos
     FROM tickets"
)->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Atalanta | Panel Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../login.css">
<style>
:root {
    --red: #db0936;
    --red-dark: #7c041e;
    --bg: #0a0a0a;
    --surface: rgba(20,5,5,0.9);
    --border: rgba(220,38,38,0.3);
    --text: #fff;
    --text2: #94a3b8;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; min-height:100vh; }
.topbar {
    background: rgba(10,0,0,0.95);
    border-bottom: 1px solid var(--border);
    padding: .8rem 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: sticky; top:0; z-index:100;
    backdrop-filter: blur(10px);
}
.topbar-brand { font-family:'Outfit',sans-serif; font-weight:800; font-size:1.2rem; }
.topbar-brand span { color: var(--red); }
.topbar-user { display:flex; align-items:center; gap:1rem; font-size:.85rem; color:var(--text2); }
.badge-rol {
    padding:.2rem .7rem; border-radius:20px;
    font-family:'Share Tech Mono',monospace; font-size:.7rem; text-transform:uppercase;
    background:rgba(220,38,38,0.2); border:1px solid var(--red); color:var(--red);
}
.btn-logout {
    background:transparent; border:1px solid var(--border); color:var(--text2);
    padding:.4rem 1rem; border-radius:6px; cursor:pointer; font-size:.8rem;
    font-family:'Share Tech Mono',monospace; transition:.2s;
}
.btn-logout:hover { border-color:var(--red); color:var(--red); }

.container { max-width:1300px; margin:0 auto; padding:2rem; }
.page-title { font-family:'Outfit',sans-serif; font-size:1.8rem; font-weight:800; margin-bottom:.3rem; }
.page-title span { color:var(--red); }
.page-sub { color:var(--text2); font-size:.9rem; margin-bottom:2rem; }

/* Stats */
.stats-row { display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:2rem; }
.stat-box {
    background:var(--surface); border:1px solid var(--border); border-radius:12px;
    padding:1.2rem; text-align:center;
}
.stat-box .num { font-family:'Share Tech Mono',monospace; font-size:2rem; color:var(--red); }
.stat-box .lbl { font-size:.78rem; color:var(--text2); margin-top:.3rem; text-transform:uppercase; letter-spacing:1px; }

/* Tabla */
.card {
    background:var(--surface); border:1px solid var(--border); border-radius:14px;
    overflow:hidden; margin-bottom:1.5rem;
}
.card-header { padding:1.2rem 1.5rem; border-bottom:1px solid var(--border); font-family:'Outfit',sans-serif; font-weight:700; font-size:1rem; }
table { width:100%; border-collapse:collapse; }
th { padding:.8rem 1rem; text-align:left; font-family:'Share Tech Mono',monospace; font-size:.72rem; text-transform:uppercase; letter-spacing:1px; color:var(--text2); border-bottom:1px solid var(--border); }
td { padding:.8rem 1rem; border-bottom:1px solid rgba(220,38,38,0.1); font-size:.88rem; vertical-align:middle; }
tr:last-child td { border-bottom:none; }
tr:hover td { background:rgba(220,38,38,0.04); }

.badge {
    display:inline-block; padding:.2rem .6rem; border-radius:20px;
    font-family:'Share Tech Mono',monospace; font-size:.68rem; text-transform:uppercase;
}
.badge-admin    { background:rgba(220,38,38,0.2); color:#f87171; border:1px solid rgba(220,38,38,0.4); }
.badge-jefe     { background:rgba(251,146,60,0.2); color:#fb923c; border:1px solid rgba(251,146,60,0.4); }
.badge-trabajador { background:rgba(59,130,246,0.2); color:#60a5fa; border:1px solid rgba(59,130,246,0.4); }
.badge-cliente  { background:rgba(148,163,184,0.15); color:#94a3b8; border:1px solid rgba(148,163,184,0.3); }
.badge-activo   { background:rgba(34,197,94,0.15); color:#4ade80; border:1px solid rgba(34,197,94,0.3); }
.badge-inactivo { background:rgba(239,68,68,0.15); color:#f87171; border:1px solid rgba(239,68,68,0.3); }

.select-rol {
    background:rgba(0,0,0,0.4); border:1px solid var(--border); color:var(--text);
    padding:.3rem .5rem; border-radius:6px; font-size:.82rem; cursor:pointer;
}
.btn-accion {
    background:rgba(220,38,38,0.15); border:1px solid var(--border); color:var(--text2);
    padding:.3rem .7rem; border-radius:6px; font-size:.75rem; cursor:pointer;
    font-family:'Share Tech Mono',monospace; transition:.2s; margin-left:.3rem;
}
.btn-accion:hover { background:rgba(220,38,38,0.3); color:var(--text); }

.toast-admin {
    position:fixed; bottom:2rem; right:2rem;
    background:rgba(10,0,0,0.95); border:1px solid var(--border);
    padding:.8rem 1.5rem; border-radius:10px; font-size:.85rem;
    display:none; z-index:9999; color:#4ade80;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5);
}
</style>
</head>
<body>

<div class="topbar">
    <div class="topbar-brand">Atalanta <span>//</span> Panel Admin</div>
    <div class="topbar-user">
        <span><?= htmlspecialchars($_SESSION['nombre']) ?></span>
        <span class="badge-rol">ADMIN</span>
        <a href="../auth_logout.php"><button class="btn-logout">Cerrar sesión</button></a>
    </div>
</div>

<div class="container">
    <div class="page-title">Panel de <span>Administración</span></div>
    <div class="page-sub">Gestión de usuarios, roles y estadísticas del sistema</div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-box">
            <div class="num"><?= count($usuarios) ?></div>
            <div class="lbl">Usuarios</div>
        </div>
        <div class="stat-box">
            <div class="num"><?= $stats['total_tickets'] ?? 0 ?></div>
            <div class="lbl">Tickets totales</div>
        </div>
        <div class="stat-box">
            <div class="num"><?= $stats['abiertos'] ?? 0 ?></div>
            <div class="lbl">Tickets abiertos</div>
        </div>
        <div class="stat-box">
            <div class="num"><?= $stats['resueltos'] ?? 0 ?></div>
            <div class="lbl">Tickets resueltos</div>
        </div>
    </div>

    <!-- Tabla de usuarios -->
    <div class="card">
        <div class="card-header">👥 Gestión de Usuarios y Roles</div>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Rol actual</th>
                    <th>Estado</th>
                    <th>Registro</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($usuarios as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['nombre'] . ' ' . $u['apellidos']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td>
                        <span class="badge badge-<?= $u['rol'] ?>"><?= strtoupper($u['rol']) ?></span>
                    </td>
                    <td>
                        <span class="badge badge-<?= $u['activo'] ? 'activo' : 'inactivo' ?>">
                            <?= $u['activo'] ? 'Activo' : 'Inactivo' ?>
                        </span>
                    </td>
                    <td><?= date('d/m/Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <?php if ($u['id'] !== getUserId()): ?>
                        <select class="select-rol" onchange="cambiarRol(<?= $u['id'] ?>, this.value)">
                            <?php foreach (['cliente','trabajador','jefe','admin'] as $r): ?>
                                <option value="<?= $r ?>" <?= $u['rol'] === $r ? 'selected' : '' ?>>
                                    <?= ucfirst($r) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button class="btn-accion" onclick="toggleActivo(<?= $u['id'] ?>)">
                            <?= $u['activo'] ? 'Desactivar' : 'Activar' ?>
                        </button>
                        <?php else: ?>
                        <span style="color:var(--text2);font-size:.75rem;">(tú mismo)</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="toast-admin" id="toastAdmin"></div>

<script>
async function cambiarRol(userId, nuevoRol) {
    const fd = new FormData();
    fd.append('action', 'cambiar_rol');
    fd.append('user_id', userId);
    fd.append('rol', nuevoRol);

    const res  = await fetch('admin.php', { method:'POST', body: fd });
    const data = await res.json();
    mostrarToast(data.message, data.success);
}

async function toggleActivo(userId) {
    const fd = new FormData();
    fd.append('action', 'toggle_activo');
    fd.append('user_id', userId);

    const res  = await fetch('admin.php', { method:'POST', body: fd });
    const data = await res.json();
    if (data.success) location.reload();
    else mostrarToast(data.message, false);
}

function mostrarToast(msg, ok) {
    const t = document.getElementById('toastAdmin');
    t.textContent = msg;
    t.style.color   = ok ? '#4ade80' : '#f87171';
    t.style.display = 'block';
    setTimeout(() => t.style.display = 'none', 3000);
}
</script>
</body>
</html>
