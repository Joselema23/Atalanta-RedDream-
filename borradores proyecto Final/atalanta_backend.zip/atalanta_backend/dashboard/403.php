<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Atalanta | Acceso Denegado</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@800&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
    background:#0a0a0a; color:#fff; font-family:'Inter',sans-serif;
    min-height:100vh; display:flex; flex-direction:column;
    align-items:center; justify-content:center; text-align:center;
}
h1 { font-family:'Outfit',sans-serif; font-size:5rem; color:#db0936; margin-bottom:.5rem; }
h2 { font-family:'Share Tech Mono',monospace; font-size:1rem; color:#94a3b8; margin-bottom:2rem; letter-spacing:.1em; }
a {
    display:inline-block; padding:.8rem 2rem;
    background:linear-gradient(135deg,#b91c1c,#7f1d1d);
    color:#fff; text-decoration:none; border-radius:8px;
    font-family:'Share Tech Mono',monospace; font-size:.9rem;
    transition:.3s;
}
a:hover { filter:brightness(1.2); transform:translateY(-2px); }
</style>
</head>
<body>
    <h1>403</h1>
    <h2>// ACCESO DENEGADO — PERMISOS INSUFICIENTES</h2>
    <a href="../login.html">← Volver al inicio</a>
</body>
</html>
