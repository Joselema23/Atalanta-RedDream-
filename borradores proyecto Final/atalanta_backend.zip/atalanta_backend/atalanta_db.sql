-- ============================================================
--  ATALANTA CIBERSEGURIDAD — Base de Datos
--  Motor: MySQL 5.7+ / MariaDB 10.3+
--  Charset: utf8mb4 (soporta emojis y caracteres especiales)
-- ============================================================

CREATE DATABASE IF NOT EXISTS atalanta_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE atalanta_db;

-- ============================================================
-- TABLA: users
-- Roles: cliente, trabajador, jefe, admin
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nombre        VARCHAR(80)  NOT NULL,
    apellidos     VARCHAR(120) NOT NULL,
    email         VARCHAR(180) NOT NULL,
    telefono      VARCHAR(20)  DEFAULT NULL,
    fecha_nac     DATE         DEFAULT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol           ENUM('cliente','trabajador','jefe','admin') NOT NULL DEFAULT 'cliente',
    activo        TINYINT(1)   NOT NULL DEFAULT 1,
    token_reset   VARCHAR(64)  DEFAULT NULL,
    token_expiry  DATETIME     DEFAULT NULL,
    intentos_login TINYINT UNSIGNED NOT NULL DEFAULT 0,
    bloqueado_hasta DATETIME   DEFAULT NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uq_email (email),
    INDEX idx_rol   (rol),
    INDEX idx_activo (activo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- TABLA: tickets
-- Estados: abierto, en_progreso, resuelto, cerrado
-- ============================================================
CREATE TABLE IF NOT EXISTS tickets (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    titulo        VARCHAR(200) NOT NULL,
    descripcion   TEXT         NOT NULL,
    prioridad     ENUM('baja','media','alta','critica') NOT NULL DEFAULT 'media',
    estado        ENUM('abierto','en_progreso','resuelto','cerrado') NOT NULL DEFAULT 'abierto',
    categoria     VARCHAR(80)  DEFAULT NULL,
    cliente_id    INT UNSIGNED NOT NULL,
    trabajador_id INT UNSIGNED DEFAULT NULL,
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_ticket_cliente    FOREIGN KEY (cliente_id)    REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_ticket_trabajador FOREIGN KEY (trabajador_id) REFERENCES users(id) ON DELETE SET NULL,

    INDEX idx_estado      (estado),
    INDEX idx_cliente     (cliente_id),
    INDEX idx_trabajador  (trabajador_id),
    INDEX idx_prioridad   (prioridad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- TABLA: comentarios
-- Historial de comentarios por ticket
-- ============================================================
CREATE TABLE IF NOT EXISTS comentarios (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ticket_id  INT UNSIGNED NOT NULL,
    user_id    INT UNSIGNED NOT NULL,
    mensaje    TEXT         NOT NULL,
    interno    TINYINT(1)   NOT NULL DEFAULT 0,   -- 1 = solo visible para staff
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_com_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE,
    CONSTRAINT fk_com_user   FOREIGN KEY (user_id)   REFERENCES users(id)   ON DELETE CASCADE,

    INDEX idx_ticket (ticket_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- TABLA: audit_log
-- Registra acciones críticas para trazabilidad
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_log (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED DEFAULT NULL,
    accion     VARCHAR(100) NOT NULL,
    detalle    TEXT         DEFAULT NULL,
    ip         VARCHAR(45)  DEFAULT NULL,
    created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_user   (user_id),
    INDEX idx_accion (accion)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- ============================================================
-- DATOS DE EJEMPLO
-- Contraseñas generadas con password_hash('...', PASSWORD_BCRYPT)
-- admin123  -> hash incluido abajo
-- pass1234  -> hash incluido abajo
-- ============================================================

INSERT INTO users (nombre, apellidos, email, telefono, fecha_nac, password_hash, rol) VALUES
(
    'Jose', 'Lema Admin',
    'admin@atalanta.com',
    '+34 600 000 001',
    '1990-05-15',
    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- admin123
    'admin'
),
(
    'Marcos', 'Pepe Jefe',
    'jefe@atalanta.com',
    '+34 600 000 002',
    '1985-08-22',
    '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- admin123
    'jefe'
),
(
    'Laura', 'Martínez',
    'trabajador@atalanta.com',
    '+34 600 000 003',
    '1995-03-10',
    '$2y$10$TKh8H1.PfYi1zoBqHqMG3OgGcFn8wr3JFTF3x1c6BqL5nBWnZGT2a', -- pass1234
    'trabajador'
),
(
    'Carlos', 'García Cliente',
    'cliente@atalanta.com',
    '+34 600 000 004',
    '2000-11-30',
    '$2y$10$TKh8H1.PfYi1zoBqHqMG3OgGcFn8wr3JFTF3x1c6BqL5nBWnZGT2a', -- pass1234
    'cliente'
);

-- Tickets de ejemplo
INSERT INTO tickets (titulo, descripcion, prioridad, estado, categoria, cliente_id, trabajador_id) VALUES
(
    'Acceso denegado a panel de control',
    'No puedo acceder al panel desde esta mañana. Me aparece error 403.',
    'alta', 'abierto', 'Acceso', 4, NULL
),
(
    'Posible intrusión detectada',
    'El sistema de monitorización ha detectado intentos de acceso desde una IP desconocida.',
    'critica', 'en_progreso', 'Seguridad', 4, 3
),
(
    'Solicitud de auditoría red interna',
    'Necesitamos una auditoría completa de la red antes del cierre de trimestre.',
    'media', 'abierto', 'Auditoría', 4, NULL
);

-- Comentarios de ejemplo
INSERT INTO comentarios (ticket_id, user_id, mensaje, interno) VALUES
(2, 3, 'He iniciado el análisis de los logs. La IP origen es 185.220.101.x (nodo Tor). Procedemos a bloqueo.', 0),
(2, 4, 'Gracias, ¿cuándo estará resuelto?', 0),
(2, 3, 'NOTA INTERNA: revisar reglas firewall del cliente antes de cerrar.', 1);

-- Registro en audit_log
INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES
(1, 'LOGIN', 'Acceso correcto al sistema', '127.0.0.1'),
(3, 'TICKET_UPDATE', 'Cambio estado ticket #2 a en_progreso', '127.0.0.1');
