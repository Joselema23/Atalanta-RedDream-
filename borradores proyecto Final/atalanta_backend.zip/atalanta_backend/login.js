// ============================================================
//  login.js — Lógica del frontend de autenticación
//  Conecta con auth_login.php y auth_register.php via fetch
// ============================================================

// ---------- Tabs Login / Registro ----------
function switchTab(tab) {
    const panels = document.querySelectorAll('.panel');
    const btns   = document.querySelectorAll('.tab-btn');
    const ind    = document.getElementById('tabIndicator');

    panels.forEach(p => p.classList.remove('active'));
    btns.forEach(b   => b.classList.remove('active'));

    document.getElementById('panel-' + tab).classList.add('active');
    if (tab === 'login') {
        btns[0].classList.add('active');
        if (ind) ind.style.transform = 'translateX(0)';
    } else {
        btns[1].classList.add('active');
        if (ind) ind.style.transform = 'translateX(100%)';
    }
}

// ---------- Pasos del registro ----------
function goStep(step) {
    // Validar paso actual antes de avanzar
    if (step === 2 && !validarPaso1()) return;
    if (step === 3 && !validarPaso2()) return;

    document.querySelectorAll('.reg-step').forEach((s, i) => {
        s.classList.toggle('active', i + 1 === step);
    });
    document.querySelectorAll('.step').forEach((s, i) => {
        s.classList.toggle('active', i + 1 <= step);
    });
    document.querySelectorAll('.step-line').forEach((l, i) => {
        l.classList.toggle('active', i + 1 < step);
    });
}

// ---------- Validación paso 1 ----------
function validarPaso1() {
    const email = document.getElementById('reg-email').value.trim();
    const pass  = document.getElementById('reg-pass').value;
    const pass2 = document.getElementById('reg-pass2').value;

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        showToast('Introduce un email válido.', 'error'); return false;
    }
    if (pass.length < 8) {
        showToast('La contraseña debe tener al menos 8 caracteres.', 'error'); return false;
    }
    if (!/[A-Z]/.test(pass)) {
        showToast('La contraseña necesita al menos una mayúscula.', 'error'); return false;
    }
    if (!/[0-9]/.test(pass)) {
        showToast('La contraseña necesita al menos un número.', 'error'); return false;
    }
    if (pass !== pass2) {
        showToast('Las contraseñas no coinciden.', 'error'); return false;
    }
    return true;
}

// ---------- Validación paso 2 ----------
function validarPaso2() {
    const nombre    = document.getElementById('reg-nombre').value.trim();
    const apellidos = document.getElementById('reg-apellido').value.trim();
    if (!nombre)    { showToast('El nombre es obligatorio.', 'error');    return false; }
    if (!apellidos) { showToast('Los apellidos son obligatorios.', 'error'); return false; }
    return true;
}

// ---------- Fuerza de contraseña ----------
function checkStrength(val) {
    const bar  = document.getElementById('strengthBar');
    const text = document.getElementById('strengthText');
    if (!bar || !text) return;

    let score = 0;
    if (val.length >= 8)          score++;
    if (/[A-Z]/.test(val))        score++;
    if (/[0-9]/.test(val))        score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    if (val.length >= 12)         score++;

    const niveles = [
        { color:'#ef4444', label:'Muy débil',  width:'20%'  },
        { color:'#f97316', label:'Débil',       width:'40%'  },
        { color:'#eab308', label:'Regular',     width:'60%'  },
        { color:'#22c55e', label:'Fuerte',      width:'80%'  },
        { color:'#16a34a', label:'Muy fuerte',  width:'100%' },
    ];
    const n = niveles[Math.min(score, 4)];
    bar.style.width      = n.width;
    bar.style.background = n.color;
    text.textContent     = n.label;
    text.style.color     = n.color;
}

// ============================================================
//  LOGIN — Envío a auth_login.php
// ============================================================
async function handleLogin() {
    const email = document.getElementById('login-email').value.trim();
    const pass  = document.getElementById('login-pass').value;
    const btn   = document.getElementById('loginBtn');

    if (!email || !pass) {
        showToast('Rellena email y contraseña.', 'error');
        return;
    }

    setLoading(btn, true);

    try {
        const res  = await fetch('auth_login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password: pass })
        });

        const data = await res.json();

        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => {
                window.location.href = data.redirect;
            }, 1000);
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('Error de conexión. Inténtalo más tarde.', 'error');
        console.error(err);
    } finally {
        setLoading(btn, false);
    }
}

// ============================================================
//  REGISTRO — Envío a auth_register.php
// ============================================================
async function handleRegister() {
    if (!validarPaso1() || !validarPaso2()) return;

    const terms = document.getElementById('terms');
    if (terms && !terms.checked) {
        showToast('Debes aceptar los términos y condiciones.', 'error');
        return;
    }

    const btn = document.getElementById('registerBtn');
    setLoading(btn, true);

    const payload = {
        email:     document.getElementById('reg-email').value.trim(),
        password:  document.getElementById('reg-pass').value,
        password2: document.getElementById('reg-pass2').value,
        nombre:    document.getElementById('reg-nombre').value.trim(),
        apellidos: document.getElementById('reg-apellido').value.trim(),
        telefono:  document.getElementById('reg-tel')?.value.trim()   || '',
        fecha_nac: document.getElementById('reg-fecha')?.value        || '',
    };

    try {
        const res  = await fetch('auth_register.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await res.json();

        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => switchTab('login'), 2000);
        } else {
            showToast(data.message, 'error');
        }
    } catch (err) {
        showToast('Error de conexión. Inténtalo más tarde.', 'error');
    } finally {
        setLoading(btn, false);
    }
}

// ---------- Toast ----------
function showToast(msg, type = 'success') {
    const toast     = document.getElementById('toast');
    const toastMsg  = document.getElementById('toastMsg');
    const toastIcon = document.getElementById('toastIcon');
    if (!toast) return;

    toastMsg.textContent  = msg;
    toastIcon.textContent = type === 'success' ? '✓' : '✕';
    toast.className       = 'toast show ' + type;

    setTimeout(() => toast.classList.remove('show'), 3500);
}

// ---------- Loading state en botones ----------
function setLoading(btn, state) {
    if (!btn) return;
    const text    = btn.querySelector('.btn-text');
    const spinner = btn.querySelector('.btn-spinner');
    btn.disabled  = state;
    if (text)    text.style.display    = state ? 'none'         : '';
    if (spinner) spinner.style.display = state ? 'inline-flex'  : 'none';
}

// ---------- Partículas de fondo (decorativas) ----------
(function initParticles() {
    const container = document.getElementById('particles');
    if (!container) return;
    for (let i = 0; i < 30; i++) {
        const p = document.createElement('div');
        p.className = 'particle';
        p.style.cssText = `
            left:${Math.random()*100}%;
            top:${Math.random()*100}%;
            animation-delay:${Math.random()*8}s;
            animation-duration:${6+Math.random()*10}s;
            width:${2+Math.random()*3}px;
            height:${2+Math.random()*3}px;
        `;
        container.appendChild(p);
    }
})();

// ---------- Enter para submit ----------
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('login-pass')?.addEventListener('keydown', e => {
        if (e.key === 'Enter') handleLogin();
    });
});
