<?php
// ============================================================
//  auth_logout.php — Cierre de sesión seguro
// ============================================================
require_once 'config.php';

session_name(SESSION_NAME);
session_start();

// Registrar logout en audit si hay sesión activa
if (isset($_SESSION['user_id'])) {
    try {
        $pdo = Database::connect();
        $pdo->prepare(
            "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, 'LOGOUT', 'Cierre de sesión', :ip)"
        )->execute([
            ':uid' => $_SESSION['user_id'],
            ':ip'  => $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'
        ]);
    } catch (Exception $e) {}
}

// Destruir sesión completamente
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(), '', time() - 42000,
        $params['path'], $params['domain'],
        $params['secure'], $params['httponly']
    );
}
session_destroy();

header('Location: login.html');
exit;
