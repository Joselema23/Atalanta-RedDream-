<?php
// ============================================================
//  auth_check.php — Middleware de sesión y control de roles
//  Incluir con require_once al inicio de cada página protegida
//
//  Uso básico:
//    require_once '../auth_check.php';
//    requireRol(['admin', 'jefe']);   // Solo admin o jefe
//    requireRol(['cliente']);         // Solo cliente
// ============================================================

require_once __DIR__ . '/config.php';

// ---------- Iniciar sesión segura ----------
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Strict');

session_name(SESSION_NAME);
session_set_cookie_params([
    'lifetime' => SESSION_LIFETIME,
    'path'     => '/',
    'httponly' => true,
    'samesite' => 'Strict',
]);
session_start();

// ============================================================
//  requireLogin() — Redirige al login si no hay sesión
// ============================================================
function requireLogin(): void {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../login.html');
        exit;
    }

    // Protección contra session hijacking:
    // Verificar que la IP y User-Agent no han cambiado
    $ip = $_SERVER['REMOTE_ADDR']     ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

    if ($_SESSION['ip'] !== $ip || $_SESSION['ua'] !== $ua) {
        session_destroy();
        header('Location: ../login.html?error=session_invalid');
        exit;
    }

    // Verificar expiración manual de sesión
    if (isset($_SESSION['login_at']) && (time() - $_SESSION['login_at']) > SESSION_LIFETIME) {
        session_destroy();
        header('Location: ../login.html?error=session_expired');
        exit;
    }

    // Renovar timestamp de actividad
    $_SESSION['login_at'] = time();
}

// ============================================================
//  requireRol() — Verifica que el rol sea el permitido
// ============================================================
function requireRol(array $rolesPermitidos): void {
    requireLogin();

    if (!in_array($_SESSION['rol'], $rolesPermitidos, true)) {
        http_response_code(403);
        include __DIR__ . '/dashboard/403.php';
        exit;
    }
}

// ============================================================
//  getRolActual() — Devuelve el rol del usuario en sesión
// ============================================================
function getRolActual(): string {
    return $_SESSION['rol'] ?? '';
}

// ============================================================
//  getUserId() — Devuelve el ID del usuario en sesión
// ============================================================
function getUserId(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}

// ============================================================
//  isLoggedIn() — Devuelve true si hay sesión activa
// ============================================================
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}
