<?php
// ============================================================
//  auth_register.php — Endpoint de registro de nuevos usuarios
//  Ruta: gestor de incidencias1/auth_register.php
//  Método: POST (JSON)
// ============================================================

require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit(json_encode(['success' => false, 'message' => 'Método no permitido.']));
}

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');

// --- Leer JSON ---
$input = json_decode(file_get_contents('php://input'), true);

$email     = trim($input['email']     ?? '');
$password  = trim($input['password']  ?? '');
$password2 = trim($input['password2'] ?? '');
$nombre    = trim($input['nombre']    ?? '');
$apellidos = trim($input['apellidos'] ?? '');
$telefono  = trim($input['telefono']  ?? '');
$fecha_nac = trim($input['fecha_nac'] ?? '');

// ============================================================
//  VALIDACIONES
// ============================================================
$errores = [];

// Email
if (empty($email)) {
    $errores[] = 'El email es obligatorio.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errores[] = 'Formato de email no válido.';
} elseif (strlen($email) > 180) {
    $errores[] = 'Email demasiado largo.';
}

// Contraseña — mínimo 8 chars, al menos 1 mayúscula, 1 número
if (empty($password)) {
    $errores[] = 'La contraseña es obligatoria.';
} elseif (strlen($password) < 8) {
    $errores[] = 'La contraseña debe tener al menos 8 caracteres.';
} elseif (strlen($password) > 128) {
    $errores[] = 'Contraseña demasiado larga.';
} elseif (!preg_match('/[A-Z]/', $password)) {
    $errores[] = 'La contraseña debe tener al menos una letra mayúscula.';
} elseif (!preg_match('/[0-9]/', $password)) {
    $errores[] = 'La contraseña debe tener al menos un número.';
}

// Confirmación
if ($password !== $password2) {
    $errores[] = 'Las contraseñas no coinciden.';
}

// Nombre
if (empty($nombre)) {
    $errores[] = 'El nombre es obligatorio.';
} elseif (strlen($nombre) > 80) {
    $errores[] = 'Nombre demasiado largo.';
} elseif (!preg_match('/^[\p{L}\s\-\'\.]+$/u', $nombre)) {
    $errores[] = 'El nombre solo puede contener letras.';
}

// Apellidos
if (empty($apellidos)) {
    $errores[] = 'Los apellidos son obligatorios.';
} elseif (strlen($apellidos) > 120) {
    $errores[] = 'Apellidos demasiado largos.';
}

// Teléfono (opcional pero validado si se envía)
if (!empty($telefono) && !preg_match('/^\+?[\d\s\-]{7,20}$/', $telefono)) {
    $errores[] = 'Formato de teléfono no válido.';
}

// Fecha de nacimiento (opcional)
if (!empty($fecha_nac)) {
    $dt = DateTime::createFromFormat('Y-m-d', $fecha_nac);
    if (!$dt) {
        $errores[] = 'Fecha de nacimiento no válida.';
    } else {
        $edad = (new DateTime())->diff($dt)->y;
        if ($edad < 16) {
            $errores[] = 'Debes tener al menos 16 años para registrarte.';
        }
    }
}

if (!empty($errores)) {
    exit(json_encode(['success' => false, 'message' => implode(' ', $errores)]));
}

// ============================================================
//  COMPROBAR EMAIL ÚNICO
// ============================================================
$pdo = Database::connect();

$stmt = $pdo->prepare("SELECT id FROM users WHERE email = :email LIMIT 1");
$stmt->execute([':email' => $email]);

if ($stmt->fetch()) {
    exit(json_encode(['success' => false, 'message' => 'Este email ya está registrado.']));
}

// ============================================================
//  HASHEAR CONTRASEÑA con bcrypt (coste 12)
// ============================================================
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

// ============================================================
//  INSERTAR USUARIO — rol por defecto: cliente
// ============================================================
$stmt = $pdo->prepare(
    "INSERT INTO users (nombre, apellidos, email, telefono, fecha_nac, password_hash, rol)
     VALUES (:nombre, :apellidos, :email, :telefono, :fecha_nac, :hash, 'cliente')"
);

$stmt->execute([
    ':nombre'    => htmlspecialchars($nombre,    ENT_QUOTES, 'UTF-8'),
    ':apellidos' => htmlspecialchars($apellidos, ENT_QUOTES, 'UTF-8'),
    ':email'     => $email,
    ':telefono'  => !empty($telefono)  ? $telefono  : null,
    ':fecha_nac' => !empty($fecha_nac) ? $fecha_nac : null,
    ':hash'      => $hash,
]);

$nuevoId = (int)$pdo->lastInsertId();
$ip      = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

// Registrar en audit log
$pdo->prepare(
    "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, 'REGISTER', :det, :ip)"
)->execute([':uid' => $nuevoId, ':det' => "Nuevo registro: $email", ':ip' => $ip]);

exit(json_encode([
    'success' => true,
    'message' => '¡Cuenta creada! Ya puedes iniciar sesión. Un administrador podrá asignarte un rol específico.'
]));
