<?php
// ============================================================
//  config.php — Configuración central de la aplicación
//  Coloca este archivo en: gestor de incidencias1/config.php
// ============================================================

// ---------- Entorno ----------
define('ENV', 'development'); // Cambiar a 'production' en servidor real

// ---------- Base de datos ----------
define('DB_HOST', 'localhost');
define('DB_NAME', 'atalanta_db');
define('DB_USER', 'root');       // Cambia en producción
define('DB_PASS', '');           // Cambia en producción
define('DB_CHARSET', 'utf8mb4');

// ---------- Seguridad de sesiones ----------
define('SESSION_NAME', 'atalanta_sess');
define('SESSION_LIFETIME', 3600);        // 1 hora en segundos
define('MAX_LOGIN_ATTEMPTS', 5);         // Intentos antes de bloqueo
define('LOCKOUT_TIME', 900);             // 15 minutos de bloqueo

// ---------- Rutas ----------
define('BASE_URL', 'http://localhost/inicio/gestor de incidencias1/');

// ---------- Configuración de errores según entorno ----------
if (ENV === 'development') {
    ini_set('display_errors', 1);
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 0);
    error_reporting(0);
}

// ---------- Zona horaria ----------
date_default_timezone_set('Europe/Madrid');

// ============================================================
//  Clase de conexión PDO — Singleton seguro
// ============================================================
class Database {
    private static ?PDO $instance = null;

    public static function connect(): PDO {
        if (self::$instance === null) {
            $dsn = 'mysql:host=' . DB_HOST
                 . ';dbname='    . DB_NAME
                 . ';charset='   . DB_CHARSET;

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,  // Prepares reales (anti SQLi)
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ];

            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                // No exponer detalles de conexión al usuario
                error_log('[ATALANTA DB ERROR] ' . $e->getMessage());
                http_response_code(500);
                die(json_encode([
                    'success' => false,
                    'message' => 'Error de conexión con el servidor. Inténtalo más tarde.'
                ]));
            }
        }
        return self::$instance;
    }
}
