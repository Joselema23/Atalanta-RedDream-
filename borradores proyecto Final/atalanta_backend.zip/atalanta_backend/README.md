# ATALANTA BACKEND — Guía de instalación
## Tecnologías: PHP + MySQL + XAMPP

---

## ESTRUCTURA DE ARCHIVOS A COLOCAR

```
inicio/
└── gestor de incidencias1/
    ├── login.html          ← (ya existe, no tocar)
    ├── login.css           ← (ya existe, no tocar)
    ├── login.js            ← ⚠️ REEMPLAZAR con el nuevo
    ├── config.php          ← NUEVO
    ├── auth_login.php      ← NUEVO
    ├── auth_register.php   ← NUEVO
    ├── auth_check.php      ← NUEVO
    ├── auth_logout.php     ← NUEVO
    └── dashboard/
        ├── admin.php       ← NUEVO
        ├── jefe.php        ← (próxima fase)
        ├── trabajador.php  ← (próxima fase)
        ├── cliente.php     ← (próxima fase)
        └── 403.php         ← NUEVO
```

---

## PASO 1 — Instalar XAMPP

1. Descarga XAMPP desde https://www.apachefriends.org
2. Instala en C:/xampp
3. Abre el Panel de Control de XAMPP
4. Arranca **Apache** y **MySQL** (botón Start en ambos)

---

## PASO 2 — Copiar el proyecto

Copia toda tu carpeta del proyecto dentro de:
```
C:/xampp/htdocs/
```
Debe quedar así:
```
C:/xampp/htdocs/inicio/
```

---

## PASO 3 — Crear la base de datos

1. Abre el navegador y ve a: http://localhost/phpmyadmin
2. Clic en **"Nueva"** (panel izquierdo)
3. En "Importar" selecciona el archivo **atalanta_db.sql**
4. Pulsa **Continuar**

Esto crea automáticamente:
- Base de datos: `atalanta_db`
- Tablas: `users`, `tickets`, `comentarios`, `audit_log`
- 4 usuarios de prueba ya insertados

---

## PASO 4 — Verificar config.php

Abre `gestor de incidencias1/config.php` y comprueba:

```php
define('DB_HOST', 'localhost');   // No cambiar en XAMPP local
define('DB_NAME', 'atalanta_db'); // Nombre de la BD
define('DB_USER', 'root');        // Usuario por defecto en XAMPP
define('DB_PASS', '');            // Sin contraseña en XAMPP local
```

---

## PASO 5 — Acceder al proyecto

Abre en el navegador:
```
http://localhost/inicio/gestor de incidencias1/login.html
```

---

## USUARIOS DE PRUEBA

| Email                    | Contraseña | Rol        |
|--------------------------|------------|------------|
| admin@atalanta.com       | admin123   | Admin      |
| jefe@atalanta.com        | admin123   | Jefe       |
| trabajador@atalanta.com  | pass1234   | Trabajador |
| cliente@atalanta.com     | pass1234   | Cliente    |

---

## SEGURIDAD IMPLEMENTADA

✅ Contraseñas con bcrypt (coste 12)
✅ Consultas preparadas PDO (anti SQL Injection)
✅ Sanitización con htmlspecialchars (anti XSS)
✅ Anti brute-force: bloqueo tras 5 intentos (15 min)
✅ Session fixation prevention (regenerate_id)
✅ Session hijacking detection (IP + User-Agent)
✅ Expiración automática de sesión (1 hora)
✅ Cabeceras de seguridad HTTP
✅ Control de acceso por rol en cada página
✅ Audit log de todas las acciones críticas
✅ User enumeration prevention (respuesta genérica)
✅ Validación en frontend Y backend

---

## FLUJO DE FUNCIONAMIENTO

```
Usuario abre login.html
    ↓
Rellena formulario → fetch a auth_login.php
    ↓
PHP verifica: email existe, contraseña correcta,
             cuenta activa, no bloqueada
    ↓
Si OK → Sesión PHP + redirige según rol:
    - admin      → dashboard/admin.php
    - jefe       → dashboard/jefe.php
    - trabajador → dashboard/trabajador.php
    - cliente    → dashboard/cliente.php
    ↓
Cada dashboard incluye auth_check.php
que verifica sesión + rol en cada carga
```
