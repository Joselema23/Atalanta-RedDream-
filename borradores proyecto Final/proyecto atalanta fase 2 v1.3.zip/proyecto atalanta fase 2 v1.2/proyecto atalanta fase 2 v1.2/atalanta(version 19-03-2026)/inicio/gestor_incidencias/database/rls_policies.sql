-- =====================================================================================
-- SCRIPT DE SEGURIDAD PARA SUPABASE (RLS y FUNCIONES RPC)
-- Prioridad Crítica - Previene escalada de privilegios y borrado de bases de datos
-- =====================================================================================

-- 1. Habilitar la seguridad a nivel de fila (RLS) en la tabla perfiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 2. Permitir lectura completa si es necesario para el sistema (Ej. todos pueden ver nombres)
-- Opcional: restringir para que solo admin o trabajadores vean a todos.
CREATE POLICY "Permitir lectura de todos los perfiles a usuarios autenticados" 
ON public.profiles FOR SELECT 
TO authenticated 
USING (true);

-- 3. Permitir Inserciones (INSERT) solo cuando el usuario se está creando a sí mismo
-- El 'rol' DEBE forzarse como 'cliente' en el nivel de base de datos o aplicación.
CREATE POLICY "Un usuario puede insertar su propio perfil"
ON public.profiles FOR INSERT 
WITH CHECK ( auth.uid() = id );

-- 4. Permitir Modificaciones (UPDATE)
-- Regla de Oro: Un usuario solo puede modificarse a sí mismo, PERO NO su ROL
CREATE POLICY "Un usuario puede actualizar su propio perfil (no el rol)"
ON public.profiles FOR UPDATE
USING ( auth.uid() = id )
WITH CHECK ( 
  auth.uid() = id
  -- NOTA: Esto solo prohíbe el UPDATE convencional si el campo cambia.
  -- Para forzarlo totalmente a nivel DB, es mejor usar un TRIGGER o revocar permisos 
  -- de UPDATE a la columna `rol` para roles genéricos, o gestionarlo estrictamente mediante RPC.
);

-- =====================================================================================
-- 5. FUNCTION RPC (DATABASE FUNCTION) PARA ELEVACIÓN DE PRIVILEGIOS SEGURA
-- =====================================================================================
-- Esta función es la ÚNICA manera válida de que el frontend intente cambiar el rol
-- de alguien en la plataforma de Atalanta, y primero verifica que el invocador sea ADMIN.

CREATE OR REPLACE FUNCTION asignar_rol(p_user_id UUID, p_nuevo_rol TEXT)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER -- Se ejecuta con privilegios del creador (bypass RLS localmente)
AS $$
DECLARE
    v_invocador_rol TEXT;
BEGIN
    -- 1. Obtener el ID del invocador (quién hace la llamada)
    -- 2. Consultar el rol del invocador
    SELECT rol INTO v_invocador_rol 
    FROM public.profiles 
    WHERE id = auth.uid();

    -- 3. Comprobar seguridad: ¿Es Admin?
    IF v_invocador_rol = 'admin' THEN
        -- Es admin, se permite el cambio
        UPDATE public.profiles 
        SET rol = p_nuevo_rol 
        WHERE id = p_user_id;
    ELSE
        -- No es admin, lanzar error bloqueante
        RAISE EXCEPTION 'Acceso denegado: solo un administrador puede cambiar roles. (Invocador: %)', v_invocador_rol;
    END IF;
END;
$$;


-- =====================================================================================
-- 6. POLÍTICAS PARA TICKETS (INCIDENCIAS)
-- =====================================================================================
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;

-- Lectura:
CREATE POLICY "Los clientes ven sus tickets, trabajadores los suyos, admins todos"
ON public.tickets FOR SELECT 
USING (
  cliente_id = auth.uid() OR 
  trabajador_id = auth.uid() OR 
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND rol IN ('admin', 'jefe'))
);

-- Inserción (Crear Ticket) - Solo clientes crean tickets para si mismos (o workers creando)
CREATE POLICY "Clientes pueden crear tickets"
ON public.tickets FOR INSERT
WITH CHECK ( cliente_id = auth.uid() );

-- Modificación (Update) - Trabajadores actualizan ticket si están asignados (estado, comentario)
CREATE POLICY "Trabajador asignado puede actualizar el ticket"
ON public.tickets FOR UPDATE
USING (
  trabajador_id = auth.uid() OR
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND rol IN ('admin', 'jefe'))
);
