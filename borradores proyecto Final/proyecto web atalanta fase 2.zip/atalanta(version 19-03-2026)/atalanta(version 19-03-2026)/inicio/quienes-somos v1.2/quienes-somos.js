/* ─── HERO parallax ─── */
(function() {
  var hero    = document.getElementById('hero');
  if (!hero) return;
  var content = hero.querySelector('.hero-content');
  var right   = hero.querySelector('.hero-right');
  var cue     = hero.querySelector('.hero-scroll');
  var orbs    = hero.querySelectorAll('.orb');
  var grid    = hero.querySelector('.hero-grid');

  function onScroll() {
    var sy   = window.pageYOffset;
    var hh   = hero.offsetHeight;
    var p    = Math.min(sy / (hh * 0.4), 1);
    var fade = Math.max(0, 1 - p * 1.6);
    var moveY = p * -48;
    if (content) { content.style.opacity = fade; content.style.transform = 'translateY(' + moveY + 'px)'; }
    if (right)   { right.style.opacity   = fade; right.style.transform   = 'translate(0, calc(-50% + ' + (moveY * 0.6) + 'px))'; }
    if (cue)     { cue.style.opacity     = Math.max(0, 1 - p * 4); }
    orbs.forEach(function(o) { o.style.opacity = Math.max(0, 1 - p * 2.2); });
    if (grid)    { grid.style.opacity    = Math.max(0.15, 1 - p * 1.3); }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
})();

/* ─── SCROLL REVEAL ─── */
(function() {
  var els = document.querySelectorAll('.reveal');
  if (!els.length) return;
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var siblings = Array.prototype.slice.call(entry.target.parentElement.querySelectorAll('.reveal:not(.visible)'));
        var idx = siblings.indexOf(entry.target);
        setTimeout(function() { entry.target.classList.add('visible'); }, idx * 65);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });
  els.forEach(function(el) { observer.observe(el); });
})();

/* ─── SMOOTH SCROLL ─── */
(function() {
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var id = a.getAttribute('href');
      if (id === '#') return;
      var target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        var top = target.getBoundingClientRect().top + window.pageYOffset - 68;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    });
  });
})();

/* ─── COUNTER ANIMATION ─── */
(function() {
  var counters = document.querySelectorAll('.historia-data-box .num');
  if (!counters.length) return;
  var done = false;

  var targets = [];
  counters.forEach(function(el) {
    var accent   = el.querySelector('span');
    var accentTxt = accent ? accent.outerHTML : '';
    var raw      = el.textContent.trim().replace(/[^0-9.,]/g, '');
    var isFloat  = raw.indexOf(',') !== -1;
    var val      = parseFloat(raw.replace(',', '.'));
    targets.push({ el: el, val: val, isFloat: isFloat, accentTxt: accentTxt });
  });

  var obs = new IntersectionObserver(function(entries) {
    if (done) return;
    entries.forEach(function(entry) {
      if (!entry.isIntersecting) return;
      done = true;
      targets.forEach(function(item) {
        if (isNaN(item.val)) return;
        var start = 0; var duration = 1500; var startTime = null;
        function step(ts) {
          if (!startTime) startTime = ts;
          var p    = Math.min((ts - startTime) / duration, 1);
          var ease = 1 - Math.pow(1 - p, 3);
          var cur  = start + (item.val - start) * ease;
          var disp = item.isFloat ? cur.toFixed(1).replace('.', ',') : Math.round(cur).toString();
          item.el.innerHTML = '+' + disp + item.accentTxt;
          if (p < 1) requestAnimationFrame(step);
        }
        requestAnimationFrame(step);
      });
      obs.disconnect();
    });
  }, { threshold: 0.4 });

  var trigger = document.querySelector('.historia-data-row');
  if (trigger) obs.observe(trigger);
})();

/* ─── NAV active on scroll ─── */
(function() {
  var sections = document.querySelectorAll('section[id]');
  var navLinks = document.querySelectorAll('.nav-links a');
  if (!navLinks.length) return;
  window.addEventListener('scroll', function() {
    var scrollY = window.pageYOffset + 120;
    sections.forEach(function(sec) {
      if (scrollY >= sec.offsetTop && scrollY < sec.offsetTop + sec.offsetHeight) {
        navLinks.forEach(function(a) { a.classList.remove('active'); });
      }
    });
  }, { passive: true });
})();
