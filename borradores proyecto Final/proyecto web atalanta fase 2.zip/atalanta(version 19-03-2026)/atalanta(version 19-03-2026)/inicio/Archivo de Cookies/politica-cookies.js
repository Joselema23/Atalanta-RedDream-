/* ─── SCROLL REVEAL ─── */
(function() {
  var els = document.querySelectorAll('.reveal');
  if (!els.length) return;
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var siblings = Array.prototype.slice.call(
          entry.target.parentElement.querySelectorAll('.reveal:not(.visible)')
        );
        var idx = siblings.indexOf(entry.target);
        setTimeout(function() { entry.target.classList.add('visible'); }, idx * 65);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });
  els.forEach(function(el) { observer.observe(el); });
})();

/* ─── SMOOTH SCROLL ─── */
(function() {
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var id = a.getAttribute('href');
      if (id === '#') return;
      var target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        window.scrollTo({ top: target.getBoundingClientRect().top + window.pageYOffset - 68, behavior: 'smooth' });
      }
    });
  });
})();

/* ─── HAMBURGER ─── */
(function() {
  var btn = document.getElementById('hamburgerBtn');
  var nav = document.getElementById('mobileNav');
  if (!btn || !nav) return;
  btn.addEventListener('click', function() {
    btn.classList.toggle('open');
    nav.classList.toggle('open');
  });
  nav.querySelectorAll('a').forEach(function(a) {
    a.addEventListener('click', function() {
      btn.classList.remove('open');
      nav.classList.remove('open');
    });
  });
})();

/* ─── HERO WORD ENTRANCE ─── */
(function() {
  var words = document.querySelectorAll('.hero h1 .w');
  if (!words.length) return;
  words.forEach(function(w, i) {
    setTimeout(function() { w.classList.add('visible'); }, 100 + i * 120);
  });
})();

/* ─── HERO PARALLAX ─── */
(function() {
  var hero = document.querySelector('.hero');
  var content = document.querySelector('.hero-content');
  if (!hero || !content) return;
  function onScroll() {
    var scrollY = window.pageYOffset;
    var heroH = hero.offsetHeight;
    if (scrollY > heroH) return;
    var progress = scrollY / heroH;
    content.style.transform = 'translateY(' + (scrollY * 0.25) + 'px)';
    content.style.opacity = 1 - progress * 1.5;
  }
  window.addEventListener('scroll', onScroll, { passive: true });
})();

/* ─── NAV SCROLL STATE ─── */
(function() {
  var nav = document.querySelector('nav');
  if (!nav) return;
  function onScroll() {
    nav.style.background = window.pageYOffset > 40
      ? 'rgba(7,12,22,0.98)'
      : 'rgba(7,12,22,0.92)';
  }
  window.addEventListener('scroll', onScroll, { passive: true });
})();

/* ─── INTRO BAND ─── */
(function() {
  var band = document.getElementById('introBand');
  if (!band) return;
  var state = 'hidden';
  function go(s) {
    state = s;
    band.className = 'intro-band' + (s !== 'hidden' ? ' intro-' + s : '');
  }
  function onScroll() {
    var scrollY = window.pageYOffset;
    var winH = window.innerHeight;
    if (scrollY > winH * 0.3 && scrollY < winH * 1.8) {
      if (state !== 'enter') go('enter');
    } else if (scrollY >= winH * 1.8) {
      if (state !== 'left') go('left');
    } else {
      if (state !== 'hidden') go('hidden');
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ─── FORM ─── */
(function() {
  var btn = document.querySelector('.form-submit');
  if (!btn) return;
  btn.addEventListener('click', function() {
    var email = document.querySelector('input[type="email"]');
    var checkbox = document.querySelector('.form-check input[type="checkbox"]');
    if (email && !email.value.trim()) {
      email.focus();
      email.style.borderColor = 'rgba(220,6,48,0.8)';
      setTimeout(function() { email.style.borderColor = ''; }, 2000);
      return;
    }
    if (checkbox && !checkbox.checked) {
      checkbox.parentElement.style.outline = '1px solid rgba(220,6,48,0.6)';
      setTimeout(function() { checkbox.parentElement.style.outline = ''; }, 2000);
      return;
    }
    btn.textContent = '✓ Mensaje enviado';
    btn.style.background = 'rgba(34,197,94,0.15)';
    btn.style.borderColor = 'rgba(34,197,94,0.4)';
    btn.style.color = '#86efac';
    btn.disabled = true;
  });
})();
