/* ============================================================
   ATALANTA — login.js
   Supabase Auth + lógica de UI (partículas, tabs, steps, toast)
   ============================================================ */

/* ===== SUPABASE INIT ===== */
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';

const SUPABASE_URL = 'https://unpyhtqphdjrybkmwmal.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Xh-EO0Zr48pju6Bpd6DcMQ_EU4wat05'; // ← reemplaza con tu anon key

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/* ===== PARTÍCULAS ===== */
(function () {
  const container = document.getElementById('particles');
  for (let i = 0; i < 28; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.cssText = `
      left: ${Math.random() * 100}%;
      width: ${Math.random() > 0.5 ? 2 : 1}px;
      height: ${Math.random() > 0.5 ? 2 : 1}px;
      animation-duration: ${12 + Math.random() * 20}s;
      animation-delay: ${Math.random() * 15}s;
      opacity: ${0.3 + Math.random() * 0.4};
    `;
    container.appendChild(p);
  }
})();

/* ===== TABS ===== */
let currentTab = 'login';

function switchTab(tab) {
  currentTab = tab;
  const panels = document.querySelectorAll('.panel');
  const btns = document.querySelectorAll('.tab-btn');
  const indicator = document.getElementById('tabIndicator');

  panels.forEach(p => p.classList.remove('active'));
  btns.forEach(b => b.classList.remove('active'));

  document.getElementById('panel-' + tab).classList.add('active');
  if (tab === 'login') {
    btns[0].classList.add('active');
    indicator.classList.remove('right');
  } else {
    btns[1].classList.add('active');
    indicator.classList.add('right');
  }
}

/* ===== STEPS REGISTRO (ahora solo 2 pasos) ===== */
let currentStep = 1;

function goStep(n) {
  if (n > currentStep && !validateStep(currentStep)) return;
  document.getElementById('reg-step-' + currentStep).classList.remove('active');
  currentStep = n;
  document.getElementById('reg-step-' + currentStep).classList.add('active');
  updateStepIndicator();
}

function updateStepIndicator() {
  for (let i = 1; i <= 2; i++) {
    const dot = document.getElementById('step-dot-' + i);
    dot.classList.remove('active', 'done');
    if (i < currentStep) dot.classList.add('done');
    else if (i === currentStep) dot.classList.add('active');
  }
  const line = document.getElementById('step-line-1');
  if (line) line.classList.toggle('active', currentStep > 1);
}

/* ===== VALIDACIÓN ===== */
function validateStep(step) {
  if (step === 1) {
    const email = document.getElementById('reg-email').value;
    const pass = document.getElementById('reg-pass').value;
    const pass2 = document.getElementById('reg-pass2').value;
    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      showToast('⚠️ Introduce un email válido', '#ef4444'); return false;
    }
    if (pass.length < 8) {
      showToast('⚠️ La contraseña debe tener 8+ caracteres', '#ef4444'); return false;
    }
    if (pass !== pass2) {
      showToast('⚠️ Las contraseñas no coinciden', '#ef4444'); return false;
    }
  }
  if (step === 2) {
    const nombre = document.getElementById('reg-nombre').value;
    const apellido = document.getElementById('reg-apellido').value;
    if (!nombre || !apellido) {
      showToast('⚠️ Introduce tu nombre y apellidos', '#ef4444'); return false;
    }
  }
  return true;
}

/* ===== STRENGTH BAR ===== */
function checkStrength(val) {
  const bar = document.getElementById('strengthBar');
  const txt = document.getElementById('strengthText');
  let score = 0;
  if (val.length >= 8) score++;
  if (/[A-Z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;

  const levels = [
    { pct: '0%', color: 'transparent', label: '' },
    { pct: '25%', color: '#ef4444', label: 'Débil' },
    { pct: '50%', color: '#f97316', label: 'Regular' },
    { pct: '75%', color: '#eab308', label: 'Buena' },
    { pct: '100%', color: '#22c55e', label: 'Fuerte ✓' },
  ];

  const lvl = val.length === 0 ? levels[0] : levels[score] || levels[4];
  bar.style.width = lvl.pct;
  bar.style.background = lvl.color;
  txt.textContent = lvl.label;
  txt.style.color = lvl.color;
}

/* ===== LOGIN con Supabase ===== */
async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const pass = document.getElementById('login-pass').value;

  if (!email || !pass) {
    showToast('⚠️ Completa todos los campos', '#ef4444'); return;
  }

  const btn = document.getElementById('loginBtn');
  btn.classList.add('loading');

  const { data, error } = await supabase.auth.signInWithPassword({ email, password: pass });

  btn.classList.remove('loading');

  if (error) {
    showToast('✗ Credenciales incorrectas', '#ef4444'); return;
  }

  // Obtener perfil y rol del usuario
  const { data: profile } = await supabase
    .from('profiles')
    .select('rol, nombre')
    .eq('id', data.user.id)
    .single();

  showToast('✓ Acceso concedido. Bienvenido.', '#22c55e');

  // Redirigir según rol
  setTimeout(() => {
    const rol = profile?.rol || 'cliente';
    const destinos = {
      cliente:    'dashboard/cliente.html',
      trabajador: 'dashboard/trabajador.html',
      jefe:       'dashboard/jefe.html',
      admin:      'dashboard/admin.html',
    };
    window.location.href = destinos[rol] || destinos['cliente'];
  }, 1200);
}

/* ===== REGISTRO con Supabase ===== */
async function handleRegister() {
  if (!validateStep(2)) return;
  if (!document.getElementById('terms').checked) {
    showToast('⚠️ Acepta los términos y condiciones', '#ef4444'); return;
  }

  const email    = document.getElementById('reg-email').value.trim();
  const pass     = document.getElementById('reg-pass').value;
  const nombre   = document.getElementById('reg-nombre').value.trim();
  const apellido = document.getElementById('reg-apellido').value.trim();
  const tel      = document.getElementById('reg-tel').value.trim();
  const fecha    = document.getElementById('reg-fecha').value;

  const btn = document.getElementById('registerBtn');
  btn.classList.add('loading');

  // 1. Crear usuario en Supabase Auth (contraseña hasheada automáticamente)
  const { data, error } = await supabase.auth.signUp({ email, password: pass });

  if (error) {
    btn.classList.remove('loading');
    if (error.message.includes('already registered')) {
      showToast('✗ Este email ya está registrado', '#ef4444');
    } else {
      showToast('✗ Error al crear la cuenta', '#ef4444');
    }
    return;
  }

  // 2. Insertar perfil en tabla profiles (rol = cliente por defecto)
  const { error: profileError } = await supabase
    .from('profiles')
    .insert({
      id:       data.user.id,
      email:    email,
      nombre:   nombre,
      apellido: apellido,
      telefono: tel || null,
      fecha_nacimiento: fecha || null,
      rol:      'cliente',          // siempre cliente al registrarse
    });

  btn.classList.remove('loading');

  if (profileError) {
    showToast('✗ Error al guardar el perfil', '#ef4444'); return;
  }

  showToast('✓ Cuenta creada. Revisa tu email para confirmarla.', '#22c55e');
  setTimeout(() => switchTab('login'), 2000);
}

/* ===== TOAST ===== */
function showToast(msg, color) {
  const t = document.getElementById('toast');
  const m = document.getElementById('toastMsg');
  m.textContent = msg;
  t.style.borderColor = color || 'rgba(220,38,38,0.35)';
  t.classList.add('show');
  clearTimeout(t._timeout);
  t._timeout = setTimeout(() => t.classList.remove('show'), 3200);
}

/* ===== CERRAR SESIÓN (exportado para usar en dashboards) ===== */
async function logout() {
  await supabase.auth.signOut();
  window.location.href = '../gestor de incidencias1/login.html';
}

/* ===== EXPONER FUNCIONES GLOBALES ===== */
window.switchTab     = switchTab;
window.goStep        = goStep;
window.checkStrength = checkStrength;
window.handleLogin   = handleLogin;
window.handleRegister = handleRegister;
window.logout        = logout;
