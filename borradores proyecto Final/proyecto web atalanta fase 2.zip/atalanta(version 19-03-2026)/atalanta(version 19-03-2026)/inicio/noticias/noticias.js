// === NOTICIAS.JS ===

document.addEventListener('DOMContentLoaded', () => {

    // Navbar scroll
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        if (navbar) navbar.classList.toggle('scrolled', window.scrollY > 50);
    });

    // Mobile menu
    const menuBtn = document.getElementById('menu-btn');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuBtn && navLinks) {
        menuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            menuBtn.classList.toggle('active');
        });
    }

    // Interactive gradient bubble
    const interBubble = document.querySelector('.interactive');
    if (interBubble) {
        let curX = 0, curY = 0, tgX = 0, tgY = 0;
        const move = () => {
            curX += (tgX - curX) / 20;
            curY += (tgY - curY) / 20;
            interBubble.style.transform = `translate(${Math.round(curX)}px, ${Math.round(curY)}px)`;
            requestAnimationFrame(move);
        };
        window.addEventListener('mousemove', e => {
            tgX = e.clientX; tgY = e.clientY;
            if (interBubble.style.opacity === '0') interBubble.style.opacity = '1';
        });
        move();
    }

    // Scroll fade-up
    const fadeObs = new IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                obs.unobserve(entry.target);
            }
        });
    }, { threshold: 0.08 });
    document.querySelectorAll('.fade-up').forEach(el => fadeObs.observe(el));

    // Filtros
    const filterTags = document.querySelectorAll('.filter-tag');
    const allCards = document.querySelectorAll('.news-card');

    filterTags.forEach(tag => {
        tag.addEventListener('click', () => {
            filterTags.forEach(t => t.classList.remove('active'));
            tag.classList.add('active');
            const filter = tag.dataset.filter;
            allCards.forEach(card => {
                const match = filter === 'all' || card.dataset.category === filter;
                card.classList.toggle('hidden', !match);
            });
        });
    });

    // Búsqueda
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            const q = searchInput.value.toLowerCase().trim();
            document.querySelectorAll('.news-card').forEach(card => {
                card.classList.toggle('hidden', q !== '' && !card.textContent.toLowerCase().includes(q));
            });
        });
    }

    // Cargar más
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    const loadCount = document.querySelector('.load-count');
    let showing = 9;
    const total = 124;

    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', () => {
            loadMoreBtn.textContent = 'Cargando...';
            loadMoreBtn.disabled = true;
            setTimeout(() => {
                showing = Math.min(showing + 6, total);
                if (loadCount) loadCount.textContent = `Mostrando ${showing} de ${total} artículos`;
                loadMoreBtn.textContent = 'Cargar más noticias';
                loadMoreBtn.disabled = false;
                if (showing >= total) {
                    loadMoreBtn.style.display = 'none';
                    if (loadCount) loadCount.textContent = `Todos los ${total} artículos cargados`;
                }
            }, 700);
        });
    }

});