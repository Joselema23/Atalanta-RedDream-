const mysql = require('mysql2/promise');
require('dotenv').config();

// Creamos un Connection Pool (es más eficiente que abrir/cerrar conexiones constantemente)
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'gestor_incidencias',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Comprobamos la conexión al arrancar el servidor
pool.getConnection()
    .then(connection => {
        console.log('✅ Conexión a la base de datos MySQL establecida correctamente.');
        connection.release();
    })
    .catch(err => {
        console.error('❌ Error al conectar a la base de datos MySQL:', err.message);
        console.error('⚠️ ASEGÚRATE DE QUE XAMPP/WAMP (MYSQL) ESTÁ ENCENDIDO.');
    });

module.exports = pool;
