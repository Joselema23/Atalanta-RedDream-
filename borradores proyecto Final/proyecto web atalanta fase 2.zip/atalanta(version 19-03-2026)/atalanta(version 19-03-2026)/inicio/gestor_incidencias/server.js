const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const path = require('path');
require('dotenv').config();

// Inicializar la aplicación Express
const app = express();

// --- 🛡️ MIDDLEWARES DE SEGURIDAD Y CONFIGURACIÓN ---
// Helmet nos ayuda a proteger la aplicación de vulnerabilidades web estableciendo cabeceras HTTP de forma adecuada.
app.use(helmet()); 

// Habilitar CORS para permitir peticiones desde el frontend (si estuviera en otro dominio/puerto)
app.use(cors());

// Permite a Express entender el cuerpo de las peticiones en formato JSON (ej. al enviar el formulario del login)
app.use(express.json());

// --- 🌐 ARCHIVOS ESTÁTICOS (FRONTEND) ---
// Aquí serviremos los archivos HTML, CSS y JS del Front que tú has hecho
app.use(express.static(path.join(__dirname, 'public')));


// --- 🚦 RUTAS (AÚN VACÍAS, SE CREARÁN DESPUÉS) ---
// Ejemplo futuro: app.use('/api/auth', require('./routes/authRoutes'));
// Ejemplo futuro: app.use('/api/tickets', require('./routes/ticketRoutes'));


// --- 🔧 ARRANQUE DEL SERVIDOR ---
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor ejecutándose en: http://localhost:${PORT}`);
    console.log(`🛡️  Backend asegurado y listo para recibir peticiones`);
});
