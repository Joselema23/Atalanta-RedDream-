

// --- 2. Animación de números contadores ---
function animateNumber(element, target, duration = 2000) {
    const start = 1;
    const startTime = performance.now();
    
    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Función de easing
        const easeOut = 1 - Math.pow(1 - progress, 3);
        
        const current = Math.floor(start + (target - start) * easeOut);
        element.textContent = current;
        
        if (progress < 1) {
            requestAnimationFrame(update);
        } else {
            element.textContent = target;
        }
    }
    
    requestAnimationFrame(update);
}

// Observer para detectar cuando los números son visibles
const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.5
};

const numberObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const target = parseInt(entry.target.getAttribute('data-target'));
            if (!isNaN(target)) {
                animateNumber(entry.target, target, 2500);
            }
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observar todos los elementos con la clase stat-card h3
document.querySelectorAll('.stat-card h3').forEach(el => {
    numberObserver.observe(el);
});

// --- 2. Initial Reveal Animations ---
setTimeout(() => {
    document.querySelectorAll('.fade-in').forEach(el => {
        el.classList.add('visible');
    });
}, 100);

// --- 3. Navbar Glass Effect on Scroll ---
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
    if (navbar) {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }
});

// --- 4. Scroll Animations (Intersection Observer) ---
const fadeObserverOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
};

const fadeObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
        }
    });
}, fadeObserverOptions);

document.querySelectorAll('.fade-up').forEach(el => {
    fadeObserver.observe(el);
});

// Removed unused interactive bubble (no .interactive element)


// --- 6. Bento Cards Hover Effect ---
document.querySelectorAll('.bento-card').forEach(card => {

    card.addEventListener('mousemove', e => {

        const rect = card.getBoundingClientRect();

        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        card.style.setProperty('--mouse-x', `${x}px`);
        card.style.setProperty('--mouse-y', `${y}px`);

    });

});



// --- 7. Contact Form ---
const form = document.getElementById('contactForm');
const submitBtn = document.getElementById('submitBtn');
const formMessage = document.getElementById('formMessage');

if (form) {

    form.addEventListener('submit', (e) => {

        e.preventDefault();

        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        formMessage.textContent = '';
        formMessage.className = 'form-message';

        setTimeout(() => {

            submitBtn.classList.remove('loading');
            submitBtn.disabled = false;

            formMessage.textContent =
                '¡Mensaje enviado correctamente! Nos pondremos en contacto pronto.';

            formMessage.classList.add('msg-success');

            form.reset();

            setTimeout(() => {
                formMessage.textContent = '';
            }, 5000);

        }, 1500);

    });

}

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contact-form");
  
    if (!form) return;
  
    form.addEventListener("submit", function (e) {
      e.preventDefault();
  
      emailjs
        .sendForm("service_bi6vrjr", "template_kjuni65", form)
        .then(() => {
          alert("¡Formulario enviado correctamente! Te contactaremos en menos de 24h laborales.");
          form.reset();
        })
        .catch((error) => {
          console.error("Error al enviar:", error);
          alert("Hubo un problema al enviar el formulario. Inténtalo más tarde.");
        });
    });
});



