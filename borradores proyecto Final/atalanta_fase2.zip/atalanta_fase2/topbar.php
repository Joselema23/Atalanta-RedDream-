<?php
// topbar.php — Barra de navegación superior compartida
// Incluir con: <?php include '../topbar.php'; ?>
$rolLabel = strtoupper($_SESSION['rol'] ?? '');
$nombre   = htmlspecialchars($_SESSION['nombre'] ?? '');
?>
<nav class="topbar">
    <div class="topbar-brand">
        Atalanta <span>//</span> Sistema de Gestión
    </div>
    <div class="topbar-user">
        <span><?= $nombre ?></span>
        <span class="badge-rol"><?= $rolLabel ?></span>
        <a href="../auth_logout.php" class="btn-logout">Cerrar sesión</a>
    </div>
</nav>
