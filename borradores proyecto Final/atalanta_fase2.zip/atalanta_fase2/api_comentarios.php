<?php
// ============================================================
//  api_comentarios.php — API de comentarios de tickets
//  GET  ?ticket_id=X  → Devuelve comentarios del ticket
//  POST ticket_id, mensaje, interno → Añade comentario
// ============================================================
require_once 'auth_check.php';
requireLogin();

header('Content-Type: application/json; charset=utf-8');

$pdo    = Database::connect();
$userId = getUserId();
$rol    = getRolActual();

// ============================================================
//  GET — Obtener comentarios de un ticket
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $ticketId = filter_input(INPUT_GET, 'ticket_id', FILTER_VALIDATE_INT);
    if (!$ticketId) {
        exit(json_encode([]));
    }

    // Verificar acceso al ticket según rol (anti-IDOR)
    if (!puedeVerTicket($pdo, $ticketId, $userId, $rol)) {
        http_response_code(403);
        exit(json_encode(['error' => 'Sin acceso a este ticket.']));
    }

    // Los clientes NO ven comentarios internos
    $soloPublicos = ($rol === 'cliente') ? "AND c.interno = 0" : "";

    $stmt = $pdo->prepare(
        "SELECT c.id, c.mensaje, c.interno, c.created_at,
                u.nombre, u.apellidos, u.rol AS autor_rol
         FROM comentarios c
         JOIN users u ON c.user_id = u.id
         WHERE c.ticket_id = :tid $soloPublicos
         ORDER BY c.created_at ASC"
    );
    $stmt->execute([':tid' => $ticketId]);
    $rows = $stmt->fetchAll();

    $resultado = array_map(fn($c) => [
        'id'      => $c['id'],
        'autor'   => htmlspecialchars($c['nombre'] . ' ' . $c['apellidos']),
        'rol'     => $c['autor_rol'],
        'mensaje' => htmlspecialchars($c['mensaje']),
        'interno' => (bool)$c['interno'],
        'fecha'   => date('d/m/Y H:i', strtotime($c['created_at'])),
    ], $rows);

    exit(json_encode($resultado));
}

// ============================================================
//  POST — Añadir comentario
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticketId = filter_input(INPUT_POST, 'ticket_id', FILTER_VALIDATE_INT);
    $mensaje  = trim($_POST['mensaje'] ?? '');
    $interno  = (int)($_POST['interno'] ?? 0);

    if (!$ticketId || empty($mensaje)) {
        exit(json_encode(['success' => false, 'message' => 'Datos incompletos.']));
    }

    if (strlen($mensaje) > 2000) {
        exit(json_encode(['success' => false, 'message' => 'Comentario demasiado largo (máx. 2000 caracteres).']));
    }

    // Verificar acceso al ticket (anti-IDOR)
    if (!puedeVerTicket($pdo, $ticketId, $userId, $rol)) {
        http_response_code(403);
        exit(json_encode(['success' => false, 'message' => 'Sin acceso a este ticket.']));
    }

    // Los clientes nunca pueden publicar comentarios internos
    if ($rol === 'cliente') $interno = 0;

    $pdo->prepare(
        "INSERT INTO comentarios (ticket_id, user_id, mensaje, interno) VALUES (:tid, :uid, :msg, :int)"
    )->execute([
        ':tid' => $ticketId,
        ':uid' => $userId,
        ':msg' => htmlspecialchars($mensaje, ENT_QUOTES, 'UTF-8'),
        ':int' => $interno,
    ]);

    exit(json_encode(['success' => true, 'message' => 'Comentario añadido.']));
}

http_response_code(405);
exit(json_encode(['error' => 'Método no permitido.']));

// ============================================================
//  FUNCIÓN: Verificar si el usuario puede acceder al ticket
// ============================================================
function puedeVerTicket(PDO $pdo, int $ticketId, int $userId, string $rol): bool {
    // Admin y Jefe ven todos los tickets
    if (in_array($rol, ['admin', 'jefe'], true)) return true;

    $stmt = $pdo->prepare("SELECT cliente_id, trabajador_id FROM tickets WHERE id = :id LIMIT 1");
    $stmt->execute([':id' => $ticketId]);
    $ticket = $stmt->fetch();

    if (!$ticket) return false;

    // Cliente solo ve sus propios tickets
    if ($rol === 'cliente')    return (int)$ticket['cliente_id']    === $userId;
    // Trabajador solo ve los que tiene asignados
    if ($rol === 'trabajador') return (int)$ticket['trabajador_id'] === $userId;

    return false;
}
