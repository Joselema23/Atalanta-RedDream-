<?php
// dashboard_styles.css.php
// Incluido como PHP para que Apache lo sirva correctamente
// dentro del contexto PHP de cada dashboard
header('Content-Type: text/css');
?>
:root {
    --red: #db0936; --red-dark: #7c041e;
    --bg: #0a0a0a; --surface: rgba(18,5,5,0.92);
    --border: rgba(220,38,38,0.25); --border2: rgba(220,38,38,0.1);
    --text: #fff; --text2: #94a3b8;
    --radius: 12px;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg); color:var(--text); font-family:'Inter',sans-serif; min-height:100vh; }

/* ---- Topbar ---- */
.topbar {
    background:rgba(8,0,0,0.97); border-bottom:1px solid var(--border);
    padding:.75rem 2rem; display:flex; justify-content:space-between; align-items:center;
    position:sticky; top:0; z-index:200; backdrop-filter:blur(12px);
}
.topbar-brand { font-family:'Outfit',sans-serif; font-weight:800; font-size:1.15rem; }
.topbar-brand span { color:var(--red); }
.topbar-user { display:flex; align-items:center; gap:.8rem; font-size:.83rem; color:var(--text2); }
.badge-rol {
    padding:.18rem .65rem; border-radius:20px; font-family:'Share Tech Mono',monospace;
    font-size:.68rem; text-transform:uppercase;
    background:rgba(220,38,38,0.15); border:1px solid var(--red); color:var(--red);
}
.btn-logout {
    background:transparent; border:1px solid var(--border); color:var(--text2);
    padding:.35rem .9rem; border-radius:6px; cursor:pointer; font-size:.78rem;
    font-family:'Share Tech Mono',monospace; transition:.2s; text-decoration:none;
    display:inline-block;
}
.btn-logout:hover { border-color:var(--red); color:var(--red); }

/* ---- Layout ---- */
.container { max-width:1300px; margin:0 auto; padding:2rem 1.5rem; }
.page-title { font-family:'Outfit',sans-serif; font-size:1.7rem; font-weight:800; margin-bottom:.25rem; }
.page-title span { color:var(--red); }
.page-sub { color:var(--text2); font-size:.88rem; margin-bottom:1.8rem; }

/* ---- Stats ---- */
.stats-row { display:grid; grid-template-columns:repeat(4,1fr); gap:1rem; margin-bottom:1.8rem; }
.stat-box {
    background:var(--surface); border:1px solid var(--border); border-radius:var(--radius);
    padding:1.1rem; text-align:center;
}
.stat-box .num { font-family:'Share Tech Mono',monospace; font-size:1.9rem; color:var(--red); }
.stat-box .lbl { font-size:.73rem; color:var(--text2); margin-top:.25rem; text-transform:uppercase; letter-spacing:1px; }

/* ---- Card ---- */
.card { background:var(--surface); border:1px solid var(--border); border-radius:var(--radius); overflow:hidden; margin-bottom:1.5rem; }
.card-header { padding:1rem 1.4rem; border-bottom:1px solid var(--border); font-family:'Outfit',sans-serif; font-weight:700; font-size:.95rem; }
.empty-state { padding:2.5rem; text-align:center; color:var(--text2); font-size:.9rem; }

/* ---- Table ---- */
table { width:100%; border-collapse:collapse; }
th { padding:.7rem 1rem; text-align:left; font-family:'Share Tech Mono',monospace; font-size:.7rem; text-transform:uppercase; letter-spacing:1px; color:var(--text2); border-bottom:1px solid var(--border); background:rgba(0,0,0,0.3); }
td { padding:.75rem 1rem; border-bottom:1px solid var(--border2); font-size:.86rem; vertical-align:middle; }
tr:last-child td { border-bottom:none; }
tr:hover td { background:rgba(220,38,38,0.03); }

/* ---- Badges ---- */
.badge {
    display:inline-block; padding:.18rem .55rem; border-radius:20px;
    font-family:'Share Tech Mono',monospace; font-size:.66rem; text-transform:uppercase;
}
/* Estado */
.badge-estado-abierto     { background:rgba(251,146,60,.15); color:#fb923c; border:1px solid rgba(251,146,60,.3); }
.badge-estado-en_progreso { background:rgba(59,130,246,.15); color:#60a5fa; border:1px solid rgba(59,130,246,.3); }
.badge-estado-resuelto    { background:rgba(34,197,94,.15);  color:#4ade80; border:1px solid rgba(34,197,94,.3); }
.badge-estado-cerrado     { background:rgba(100,116,139,.15);color:#64748b; border:1px solid rgba(100,116,139,.3); }
/* Prioridad */
.badge-prior-baja    { background:rgba(148,163,184,.12); color:#94a3b8; border:1px solid rgba(148,163,184,.3); }
.badge-prior-media   { background:rgba(251,191,36,.12);  color:#fbbf24; border:1px solid rgba(251,191,36,.3); }
.badge-prior-alta    { background:rgba(249,115,22,.15);  color:#f97316; border:1px solid rgba(249,115,22,.3); }
.badge-prior-critica { background:rgba(239,68,68,.2);    color:#f87171; border:1px solid rgba(239,68,68,.4); animation: pulso .9s ease-in-out infinite alternate; }
@keyframes pulso { from { box-shadow:none; } to { box-shadow:0 0 8px rgba(239,68,68,.5); } }

/* ---- Buttons ---- */
.btn-primary {
    background:linear-gradient(135deg,#b91c1c,#7f1d1d); color:#fff; border:none;
    padding:.65rem 1.4rem; border-radius:8px; font-family:'Share Tech Mono',monospace;
    font-size:.82rem; text-transform:uppercase; letter-spacing:1px; cursor:pointer;
    transition:.25s;
}
.btn-primary:hover { filter:brightness(1.2); transform:translateY(-1px); }
.btn-ghost {
    background:transparent; color:var(--text2); border:1px solid var(--border);
    padding:.65rem 1.4rem; border-radius:8px; font-size:.82rem; cursor:pointer; transition:.2s;
}
.btn-ghost:hover { border-color:var(--red); color:var(--text); }
.btn-sm {
    background:rgba(220,38,38,.12); border:1px solid var(--border); color:var(--text2);
    padding:.3rem .7rem; border-radius:6px; font-size:.75rem; cursor:pointer;
    font-family:'Share Tech Mono',monospace; transition:.2s;
}
.btn-sm:hover { background:rgba(220,38,38,.25); color:var(--text); }
.btn-filter {
    background:transparent; border:1px solid var(--border); color:var(--text2);
    padding:.4rem .9rem; border-radius:20px; font-size:.78rem; cursor:pointer;
    font-family:'Share Tech Mono',monospace; transition:.2s;
}
.btn-filter.active, .btn-filter:hover { background:rgba(220,38,38,.2); border-color:var(--red); color:var(--text); }

/* ---- Selects dentro de tabla ---- */
.select-estado {
    background:rgba(0,0,0,0.5); border:1px solid var(--border); color:var(--text);
    padding:.3rem .5rem; border-radius:6px; font-size:.8rem; cursor:pointer; outline:none;
}
.select-estado:focus { border-color:var(--red); }

/* ---- Form inputs ---- */
.form-group { display:flex; flex-direction:column; gap:.35rem; margin-bottom:1rem; }
.form-group label { font-family:'Share Tech Mono',monospace; font-size:.72rem; text-transform:uppercase; letter-spacing:.8px; color:var(--text2); }
.form-group input,
.form-group select,
.form-group textarea {
    background:rgba(0,0,0,0.5); border:1px solid var(--border); border-radius:8px;
    padding:.7rem .9rem; color:var(--text); font-family:'Inter',sans-serif; font-size:.88rem;
    outline:none; transition:.25s; width:100%;
}
.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus { border-color:var(--red); box-shadow:0 0 0 3px rgba(219,9,54,.12); }
.form-group textarea { resize:vertical; min-height:90px; }
.form-row-2 { display:grid; grid-template-columns:1fr 1fr; gap:1rem; }

/* ---- Modal ---- */
.modal {
    display:none; position:fixed; inset:0; background:rgba(0,0,0,.75);
    z-index:1000; align-items:center; justify-content:center; padding:1rem;
    backdrop-filter:blur(4px);
}
.modal.show { display:flex; }
.modal-box {
    background:rgba(12,3,3,0.98); border:1px solid var(--border); border-radius:16px;
    width:100%; max-width:560px; padding:1.8rem;
    box-shadow:0 30px 60px rgba(0,0,0,.8), 0 0 30px rgba(220,38,38,.1);
    max-height:90vh; overflow-y:auto;
}
.modal-lg { max-width:720px; }
.modal-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:1.3rem; }
.modal-header h3 { font-family:'Outfit',sans-serif; font-size:1.1rem; font-weight:800; }
.modal-close { background:transparent; border:none; color:var(--text2); font-size:1.1rem; cursor:pointer; transition:.2s; }
.modal-close:hover { color:var(--red); }
.modal-footer { display:flex; gap:.7rem; justify-content:flex-end; margin-top:1.2rem; }

/* ---- Descripción de ticket ---- */
.descripcion-box {
    background:rgba(0,0,0,0.4); border:1px solid var(--border2); border-radius:8px;
    padding:.9rem 1rem; font-size:.88rem; color:var(--text2); line-height:1.6;
    white-space:pre-wrap;
}

/* ---- Comentarios ---- */
.comentario {
    background:rgba(0,0,0,0.35); border:1px solid var(--border2); border-radius:8px;
    padding:.75rem 1rem; margin-bottom:.6rem;
}
.comentario.interno { background:rgba(251,146,60,.06); border-color:rgba(251,146,60,.25); }
.com-author { font-family:'Share Tech Mono',monospace; font-size:.72rem; color:var(--red); margin-bottom:.3rem; }
.com-date   { color:var(--text2); font-size:.68rem; margin-left:.5rem; }
.com-msg    { font-size:.86rem; color:var(--text2); line-height:1.55; }

/* ---- Toast ---- */
.toast {
    position:fixed; bottom:2rem; right:2rem; min-width:260px;
    background:rgba(10,0,0,.97); border:1px solid var(--border); border-radius:10px;
    padding:.8rem 1.3rem; font-size:.85rem; z-index:9999; opacity:0;
    transform:translateY(10px); transition:.3s; pointer-events:none;
}
.toast.show { opacity:1; transform:translateY(0); }
.toast.ok   { color:#4ade80; border-color:rgba(74,222,128,.4); }
.toast.err  { color:#f87171; border-color:rgba(248,113,113,.4); }

/* ---- Responsive ---- */
@media (max-width:768px) {
    .stats-row { grid-template-columns:repeat(2,1fr); }
    .form-row-2 { grid-template-columns:1fr; }
    table { font-size:.78rem; }
    th, td { padding:.5rem .6rem; }
    .container { padding:1rem; }
}
