<?php
// ============================================================
//  dashboard/trabajador.php — Panel del Trabajador
//  Solo accesible con rol: trabajador
// ============================================================
require_once '../auth_check.php';
requireRol(['trabajador']);

$pdo    = Database::connect();
$userId = getUserId();

// --- ACCIONES POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    // Cambiar estado del ticket (solo si está asignado a él)
    if ($_POST['action'] === 'cambiar_estado') {
        $ticketId   = filter_input(INPUT_POST, 'ticket_id', FILTER_VALIDATE_INT);
        $nuevoEstado = $_POST['estado'] ?? '';
        $estadosValidos = ['en_progreso', 'resuelto', 'cerrado'];

        if (!$ticketId || !in_array($nuevoEstado, $estadosValidos, true)) {
            exit(json_encode(['success' => false, 'message' => 'Datos no válidos.']));
        }

        // Verificar que el ticket está asignado a este trabajador (anti-IDOR)
        $check = $pdo->prepare("SELECT id FROM tickets WHERE id = :id AND trabajador_id = :uid LIMIT 1");
        $check->execute([':id' => $ticketId, ':uid' => $userId]);
        if (!$check->fetch()) {
            exit(json_encode(['success' => false, 'message' => 'No tienes permiso para modificar este ticket.']));
        }

        $pdo->prepare("UPDATE tickets SET estado = :estado WHERE id = :id")
            ->execute([':estado' => $nuevoEstado, ':id' => $ticketId]);

        $pdo->prepare(
            "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, 'TICKET_UPDATE', :det, :ip)"
        )->execute([':uid' => $userId, ':det' => "Ticket #$ticketId → $nuevoEstado", ':ip' => $_SERVER['REMOTE_ADDR']]);

        exit(json_encode(['success' => true, 'message' => 'Estado actualizado correctamente.']));
    }
}

// --- Tickets asignados a este trabajador ---
$stmt = $pdo->prepare(
    "SELECT t.*,
            c.nombre AS cliente_nombre, c.apellidos AS cliente_apellidos, c.email AS cliente_email
     FROM tickets t
     JOIN users c ON t.cliente_id = c.id
     WHERE t.trabajador_id = :uid
     ORDER BY
         FIELD(t.prioridad,'critica','alta','media','baja'),
         FIELD(t.estado,'abierto','en_progreso','resuelto','cerrado'),
         t.created_at DESC"
);
$stmt->execute([':uid' => $userId]);
$misTickets = $stmt->fetchAll();

// --- Stats del trabajador ---
$stats = $pdo->prepare(
    "SELECT
        COUNT(*) AS total,
        SUM(estado = 'abierto')     AS abiertos,
        SUM(estado = 'en_progreso') AS en_progreso,
        SUM(estado = 'resuelto')    AS resueltos
     FROM tickets WHERE trabajador_id = :uid"
);
$stats->execute([':uid' => $userId]);
$miStats = $stats->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Atalanta | Panel Trabajador</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style><?php include '../dashboard_styles.css.php'; ?></style>
</head>
<body>

<?php include '../topbar.php'; ?>

<div class="container">
    <div class="page-title">Panel <span>Trabajador</span></div>
    <div class="page-sub">Tickets asignados a ti — gestiona su progreso y comunicación</div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-box"><div class="num"><?= $miStats['total'] ?? 0 ?></div><div class="lbl">Asignados</div></div>
        <div class="stat-box"><div class="num" style="color:#f97316"><?= $miStats['abiertos'] ?? 0 ?></div><div class="lbl">Pendientes</div></div>
        <div class="stat-box"><div class="num" style="color:#60a5fa"><?= $miStats['en_progreso'] ?? 0 ?></div><div class="lbl">En progreso</div></div>
        <div class="stat-box"><div class="num" style="color:#4ade80"><?= $miStats['resueltos'] ?? 0 ?></div><div class="lbl">Resueltos</div></div>
    </div>

    <!-- Tickets asignados -->
    <div class="card">
        <div class="card-header">🔧 Mis Tickets Asignados</div>
        <?php if (empty($misTickets)): ?>
            <div class="empty-state">No tienes tickets asignados actualmente.</div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th><th>Título</th><th>Cliente</th>
                    <th>Prioridad</th><th>Estado</th><th>Fecha</th><th>Acciones</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($misTickets as $t): ?>
                <tr>
                    <td><?= $t['id'] ?></td>
                    <td><?= htmlspecialchars($t['titulo']) ?></td>
                    <td>
                        <?= htmlspecialchars($t['cliente_nombre'].' '.$t['cliente_apellidos']) ?>
                        <div style="font-size:.75rem;color:#475569;"><?= htmlspecialchars($t['cliente_email']) ?></div>
                    </td>
                    <td><span class="badge badge-prior-<?= $t['prioridad'] ?>"><?= strtoupper($t['prioridad']) ?></span></td>
                    <td>
                        <select class="select-estado" onchange="cambiarEstado(<?= $t['id'] ?>, this.value)" <?= $t['estado'] === 'cerrado' ? 'disabled' : '' ?>>
                            <?php foreach (['abierto','en_progreso','resuelto','cerrado'] as $e): ?>
                                <option value="<?= $e ?>" <?= $t['estado'] === $e ? 'selected' : '' ?>
                                    <?= $e === 'abierto' && $t['trabajador_id'] ? '' : '' ?>>
                                    <?= ucfirst(str_replace('_',' ',$e)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
                    <td>
                        <button class="btn-sm" onclick="abrirDetalle(<?= $t['id'] ?>, '<?= htmlspecialchars(addslashes($t['titulo'])) ?>', '<?= htmlspecialchars(addslashes($t['descripcion'])) ?>')">
                            Detalle
                        </button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<!-- Modal: Detalle + Comentarios -->
<div class="modal" id="modal-detalle">
    <div class="modal-box modal-lg">
        <div class="modal-header">
            <h3 id="det-titulo">Ticket</h3>
            <button class="modal-close" onclick="cerrarModal('modal-detalle')">✕</button>
        </div>
        <div class="descripcion-box" id="det-descripcion"></div>

        <div style="margin-top:1.2rem;">
            <div style="font-family:'Share Tech Mono',monospace;font-size:.75rem;color:#94a3b8;text-transform:uppercase;letter-spacing:1px;margin-bottom:.7rem;">
                Historial de comentarios
            </div>
            <div id="lista-comentarios" style="max-height:280px;overflow-y:auto;margin-bottom:1rem;"></div>
        </div>

        <div class="form-group">
            <label>Nuevo comentario</label>
            <textarea id="nuevo-comentario" rows="3" placeholder="Añade un comentario visible para el cliente..."></textarea>
        </div>
        <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:1rem;">
            <input type="checkbox" id="com-interno" style="accent-color:#db0936;">
            <label for="com-interno" style="font-size:.82rem;color:#94a3b8;">Nota interna (no visible para el cliente)</label>
        </div>
        <div class="modal-footer">
            <button class="btn-ghost" onclick="cerrarModal('modal-detalle')">Cerrar</button>
            <button class="btn-primary" onclick="enviarComentario()">Enviar comentario</button>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>

<script>
let ticketActivo = null;

async function cambiarEstado(id, estado) {
    const fd = new FormData();
    fd.append('action',    'cambiar_estado');
    fd.append('ticket_id', id);
    fd.append('estado',    estado);
    const res  = await fetch('trabajador.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
}

function abrirDetalle(id, titulo, descripcion) {
    ticketActivo = id;
    document.getElementById('det-titulo').textContent     = 'Ticket #' + id + ' — ' + titulo;
    document.getElementById('det-descripcion').textContent = descripcion;
    cargarComentarios();
    abrirModal('modal-detalle');
}

async function cargarComentarios() {
    const res  = await fetch('../api_comentarios.php?ticket_id=' + ticketActivo);
    const data = await res.json();
    const lista = document.getElementById('lista-comentarios');
    if (!data.length) { lista.innerHTML = '<p style="color:#94a3b8;text-align:center;">Sin comentarios.</p>'; return; }
    lista.innerHTML = data.map(c => `
        <div class="comentario ${c.interno ? 'interno' : ''}">
            <div class="com-author">${c.autor} <span class="com-date">${c.fecha}</span>
                ${c.interno ? '<span style="color:#f97316;font-size:.7rem;margin-left:.4rem;">[INTERNO]</span>' : ''}
            </div>
            <div class="com-msg">${c.mensaje}</div>
        </div>`).join('');
    lista.scrollTop = lista.scrollHeight;
}

async function enviarComentario() {
    const msg     = document.getElementById('nuevo-comentario').value.trim();
    const interno = document.getElementById('com-interno').checked ? 1 : 0;
    if (!msg) { toast('Escribe un comentario.', 'err'); return; }
    const fd = new FormData();
    fd.append('ticket_id', ticketActivo);
    fd.append('mensaje',   msg);
    fd.append('interno',   interno);
    const res  = await fetch('../api_comentarios.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
    if (data.success) { document.getElementById('nuevo-comentario').value = ''; document.getElementById('com-interno').checked = false; cargarComentarios(); }
}

function abrirModal(id)  { document.getElementById(id).classList.add('show'); }
function cerrarModal(id) { document.getElementById(id).classList.remove('show'); }
function toast(msg, type) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.className = 'toast show ' + type;
    setTimeout(() => t.className = 'toast', 3500);
}
</script>
</body>
</html>
