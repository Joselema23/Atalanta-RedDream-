<?php
// ============================================================
//  dashboard/cliente.php — Panel del Cliente
//  Solo accesible con rol: cliente
// ============================================================
require_once '../auth_check.php';
requireRol(['cliente']);

$pdo    = Database::connect();
$userId = getUserId();

// --- ACCIÓN: Crear nuevo ticket ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    if ($_POST['action'] === 'crear_ticket') {
        $titulo      = trim($_POST['titulo']      ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $prioridad   = $_POST['prioridad']        ?? 'media';
        $categoria   = trim($_POST['categoria']   ?? '');

        // Validaciones
        if (empty($titulo) || strlen($titulo) > 200) {
            exit(json_encode(['success' => false, 'message' => 'Título obligatorio (máx. 200 caracteres).']));
        }
        if (empty($descripcion)) {
            exit(json_encode(['success' => false, 'message' => 'La descripción es obligatoria.']));
        }
        $prioridadesValidas = ['baja', 'media', 'alta', 'critica'];
        if (!in_array($prioridad, $prioridadesValidas, true)) {
            exit(json_encode(['success' => false, 'message' => 'Prioridad no válida.']));
        }

        $stmt = $pdo->prepare(
            "INSERT INTO tickets (titulo, descripcion, prioridad, estado, categoria, cliente_id)
             VALUES (:titulo, :descripcion, :prioridad, 'abierto', :categoria, :cliente_id)"
        );
        $stmt->execute([
            ':titulo'      => htmlspecialchars($titulo, ENT_QUOTES, 'UTF-8'),
            ':descripcion' => htmlspecialchars($descripcion, ENT_QUOTES, 'UTF-8'),
            ':prioridad'   => $prioridad,
            ':categoria'   => htmlspecialchars($categoria, ENT_QUOTES, 'UTF-8'),
            ':cliente_id'  => $userId,
        ]);

        $ticketId = $pdo->lastInsertId();
        $pdo->prepare(
            "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, 'TICKET_CREATE', :det, :ip)"
        )->execute([':uid' => $userId, ':det' => "Ticket #$ticketId creado", ':ip' => $_SERVER['REMOTE_ADDR']]);

        exit(json_encode(['success' => true, 'message' => '¡Ticket creado correctamente! Te avisaremos cuando sea asignado.']));
    }
}

// --- Obtener tickets del cliente (solo los suyos) ---
$tickets = $pdo->prepare(
    "SELECT t.*, u.nombre AS trabajador_nombre, u.apellidos AS trabajador_apellidos
     FROM tickets t
     LEFT JOIN users u ON t.trabajador_id = u.id
     WHERE t.cliente_id = :cid
     ORDER BY t.created_at DESC"
);
$tickets->execute([':cid' => $userId]);
$misTickets = $tickets->fetchAll();

// --- Stats rápidas del cliente ---
$stats = $pdo->prepare(
    "SELECT
        COUNT(*) AS total,
        SUM(estado = 'abierto')     AS abiertos,
        SUM(estado = 'en_progreso') AS en_progreso,
        SUM(estado = 'resuelto')    AS resueltos
     FROM tickets WHERE cliente_id = :cid"
);
$stats->execute([':cid' => $userId]);
$miStats = $stats->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Atalanta | Mi Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style>
<?php include '../dashboard_styles.css.php'; ?>
</style>
</head>
<body>

<?php include '../topbar.php'; ?>

<div class="container">
    <div class="page-title">Mi <span>Panel de Incidencias</span></div>
    <div class="page-sub">Crea y consulta el estado de tus tickets de soporte</div>

    <!-- Stats -->
    <div class="stats-row">
        <div class="stat-box"><div class="num"><?= $miStats['total'] ?? 0 ?></div><div class="lbl">Total tickets</div></div>
        <div class="stat-box"><div class="num" style="color:#f97316"><?= $miStats['abiertos'] ?? 0 ?></div><div class="lbl">Abiertos</div></div>
        <div class="stat-box"><div class="num" style="color:#60a5fa"><?= $miStats['en_progreso'] ?? 0 ?></div><div class="lbl">En progreso</div></div>
        <div class="stat-box"><div class="num" style="color:#4ade80"><?= $miStats['resueltos'] ?? 0 ?></div><div class="lbl">Resueltos</div></div>
    </div>

    <!-- Botón nuevo ticket -->
    <button class="btn-primary" onclick="abrirModal('modal-nuevo-ticket')" style="margin-bottom:1.5rem;">
        + Crear nuevo ticket
    </button>

    <!-- Tabla de tickets -->
    <div class="card">
        <div class="card-header">🎫 Mis Tickets</div>
        <?php if (empty($misTickets)): ?>
            <div class="empty-state">No tienes tickets aún. ¡Crea el primero!</div>
        <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>#</th><th>Título</th><th>Categoría</th>
                    <th>Prioridad</th><th>Estado</th><th>Asignado a</th>
                    <th>Fecha</th><th>Detalle</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($misTickets as $t): ?>
                <tr>
                    <td><?= $t['id'] ?></td>
                    <td><?= htmlspecialchars($t['titulo']) ?></td>
                    <td><?= htmlspecialchars($t['categoria'] ?: '—') ?></td>
                    <td><span class="badge badge-prior-<?= $t['prioridad'] ?>"><?= strtoupper($t['prioridad']) ?></span></td>
                    <td><span class="badge badge-estado-<?= $t['estado'] ?>"><?= ucfirst(str_replace('_',' ',$t['estado'])) ?></span></td>
                    <td><?= $t['trabajador_nombre'] ? htmlspecialchars($t['trabajador_nombre'].' '.$t['trabajador_apellidos']) : '<span style="color:#475569">Sin asignar</span>' ?></td>
                    <td><?= date('d/m/Y H:i', strtotime($t['created_at'])) ?></td>
                    <td><button class="btn-sm" onclick="verComentarios(<?= $t['id'] ?>, '<?= htmlspecialchars(addslashes($t['titulo'])) ?>')">Ver</button></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>

<!-- Modal: Nuevo Ticket -->
<div class="modal" id="modal-nuevo-ticket">
    <div class="modal-box">
        <div class="modal-header">
            <h3>Nuevo Ticket de Soporte</h3>
            <button class="modal-close" onclick="cerrarModal('modal-nuevo-ticket')">✕</button>
        </div>
        <div class="form-group">
            <label>Título *</label>
            <input type="text" id="nt-titulo" placeholder="Describe brevemente el problema" maxlength="200">
        </div>
        <div class="form-row-2">
            <div class="form-group">
                <label>Categoría</label>
                <select id="nt-categoria">
                    <option value="">Sin categoría</option>
                    <option value="Acceso">Acceso</option>
                    <option value="Seguridad">Seguridad</option>
                    <option value="Auditoría">Auditoría</option>
                    <option value="Red">Red</option>
                    <option value="Software">Software</option>
                    <option value="Otro">Otro</option>
                </select>
            </div>
            <div class="form-group">
                <label>Prioridad *</label>
                <select id="nt-prioridad">
                    <option value="baja">Baja</option>
                    <option value="media" selected>Media</option>
                    <option value="alta">Alta</option>
                    <option value="critica">Crítica</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label>Descripción detallada *</label>
            <textarea id="nt-descripcion" rows="5" placeholder="Explica el problema con el máximo detalle posible..."></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn-ghost" onclick="cerrarModal('modal-nuevo-ticket')">Cancelar</button>
            <button class="btn-primary" onclick="crearTicket()">Enviar ticket</button>
        </div>
    </div>
</div>

<!-- Modal: Ver comentarios -->
<div class="modal" id="modal-comentarios">
    <div class="modal-box modal-lg">
        <div class="modal-header">
            <h3 id="modal-ticket-titulo">Ticket #</h3>
            <button class="modal-close" onclick="cerrarModal('modal-comentarios')">✕</button>
        </div>
        <div id="lista-comentarios" style="max-height:350px;overflow-y:auto;margin-bottom:1rem;"></div>
        <div class="form-group">
            <label>Añadir comentario</label>
            <textarea id="nuevo-comentario" rows="3" placeholder="Escribe tu comentario..."></textarea>
        </div>
        <div class="modal-footer">
            <button class="btn-ghost" onclick="cerrarModal('modal-comentarios')">Cerrar</button>
            <button class="btn-primary" onclick="enviarComentario()">Enviar</button>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>

<script>
let ticketActivo = null;

async function crearTicket() {
    const fd = new FormData();
    fd.append('action',      'crear_ticket');
    fd.append('titulo',      document.getElementById('nt-titulo').value);
    fd.append('descripcion', document.getElementById('nt-descripcion').value);
    fd.append('prioridad',   document.getElementById('nt-prioridad').value);
    fd.append('categoria',   document.getElementById('nt-categoria').value);

    const res  = await fetch('cliente.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
    if (data.success) { cerrarModal('modal-nuevo-ticket'); setTimeout(() => location.reload(), 1500); }
}

async function verComentarios(id, titulo) {
    ticketActivo = id;
    document.getElementById('modal-ticket-titulo').textContent = 'Ticket #' + id + ' — ' + titulo;
    await cargarComentarios();
    abrirModal('modal-comentarios');
}

async function cargarComentarios() {
    const res  = await fetch('../api_comentarios.php?ticket_id=' + ticketActivo);
    const data = await res.json();
    const lista = document.getElementById('lista-comentarios');
    if (!data.length) { lista.innerHTML = '<p style="color:#94a3b8;text-align:center;padding:1rem;">Sin comentarios aún.</p>'; return; }
    lista.innerHTML = data.map(c => `
        <div class="comentario ${c.interno ? 'interno' : ''}">
            <div class="com-author">${c.autor} <span class="com-date">${c.fecha}</span></div>
            <div class="com-msg">${c.mensaje}</div>
        </div>`).join('');
    lista.scrollTop = lista.scrollHeight;
}

async function enviarComentario() {
    const msg = document.getElementById('nuevo-comentario').value.trim();
    if (!msg) { toast('Escribe un comentario.', 'err'); return; }
    const fd = new FormData();
    fd.append('ticket_id', ticketActivo);
    fd.append('mensaje',   msg);
    const res  = await fetch('../api_comentarios.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
    if (data.success) { document.getElementById('nuevo-comentario').value = ''; await cargarComentarios(); }
}

function abrirModal(id)  { document.getElementById(id).classList.add('show'); }
function cerrarModal(id) { document.getElementById(id).classList.remove('show'); }

function toast(msg, type) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.className   = 'toast show ' + type;
    setTimeout(() => t.className = 'toast', 3500);
}
</script>
</body>
</html>
