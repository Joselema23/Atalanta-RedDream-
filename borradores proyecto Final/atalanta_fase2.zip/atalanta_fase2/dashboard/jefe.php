<?php
// ============================================================
//  dashboard/jefe.php — Panel del Jefe
//  Solo accesible con rol: jefe
// ============================================================
require_once '../auth_check.php';
requireRol(['jefe', 'admin']);

$pdo    = Database::connect();
$userId = getUserId();

// --- ACCIONES POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');

    // Asignar trabajador a ticket
    if ($_POST['action'] === 'asignar_ticket') {
        $ticketId     = filter_input(INPUT_POST, 'ticket_id',    FILTER_VALIDATE_INT);
        $trabajadorId = filter_input(INPUT_POST, 'trabajador_id', FILTER_VALIDATE_INT);

        if (!$ticketId) {
            exit(json_encode(['success' => false, 'message' => 'Ticket no válido.']));
        }

        // trabajadorId puede ser 0 (desasignar) o un ID real
        $trabajadorFinal = $trabajadorId ?: null;

        // Verificar que el trabajador tiene rol correcto (anti-IDOR)
        if ($trabajadorFinal !== null) {
            $check = $pdo->prepare("SELECT id FROM users WHERE id = :id AND rol IN ('trabajador','jefe') AND activo = 1 LIMIT 1");
            $check->execute([':id' => $trabajadorFinal]);
            if (!$check->fetch()) {
                exit(json_encode(['success' => false, 'message' => 'Trabajador no válido.']));
            }
        }

        // Si se asigna, cambiar estado a en_progreso automáticamente
        $nuevoEstado = $trabajadorFinal ? 'en_progreso' : 'abierto';
        $pdo->prepare(
            "UPDATE tickets SET trabajador_id = :tid, estado = :estado WHERE id = :id"
        )->execute([':tid' => $trabajadorFinal, ':estado' => $nuevoEstado, ':id' => $ticketId]);

        $pdo->prepare(
            "INSERT INTO audit_log (user_id, accion, detalle, ip) VALUES (:uid, 'TICKET_ASSIGN', :det, :ip)"
        )->execute([
            ':uid' => $userId,
            ':det' => $trabajadorFinal ? "Ticket #$ticketId asignado a trabajador #$trabajadorFinal" : "Ticket #$ticketId desasignado",
            ':ip'  => $_SERVER['REMOTE_ADDR']
        ]);

        exit(json_encode(['success' => true, 'message' => $trabajadorFinal ? 'Ticket asignado correctamente.' : 'Asignación eliminada.']));
    }

    // Cambiar estado manualmente
    if ($_POST['action'] === 'cambiar_estado') {
        $ticketId    = filter_input(INPUT_POST, 'ticket_id', FILTER_VALIDATE_INT);
        $nuevoEstado = $_POST['estado'] ?? '';
        $estadosValidos = ['abierto', 'en_progreso', 'resuelto', 'cerrado'];

        if (!$ticketId || !in_array($nuevoEstado, $estadosValidos, true)) {
            exit(json_encode(['success' => false, 'message' => 'Datos no válidos.']));
        }

        $pdo->prepare("UPDATE tickets SET estado = :estado WHERE id = :id")
            ->execute([':estado' => $nuevoEstado, ':id' => $ticketId]);

        exit(json_encode(['success' => true, 'message' => 'Estado actualizado.']));
    }
}

// --- Obtener TODOS los tickets ---
$tickets = $pdo->query(
    "SELECT t.*,
            c.nombre  AS cliente_nombre,  c.apellidos AS cliente_apellidos,
            w.nombre  AS trabajador_nombre, w.apellidos AS trabajador_apellidos
     FROM tickets t
     JOIN  users c ON t.cliente_id = c.id
     LEFT JOIN users w ON t.trabajador_id = w.id
     ORDER BY
         FIELD(t.prioridad,'critica','alta','media','baja'),
         FIELD(t.estado,'abierto','en_progreso','resuelto','cerrado'),
         t.created_at DESC"
)->fetchAll();

// --- Lista de trabajadores disponibles ---
$trabajadores = $pdo->query(
    "SELECT id, nombre, apellidos FROM users WHERE rol IN ('trabajador','jefe') AND activo = 1 ORDER BY nombre"
)->fetchAll();

// --- Stats globales ---
$stats = $pdo->query(
    "SELECT COUNT(*) AS total,
            SUM(estado='abierto') AS abiertos,
            SUM(estado='en_progreso') AS en_progreso,
            SUM(estado='resuelto') AS resueltos,
            SUM(trabajador_id IS NULL AND estado != 'cerrado') AS sin_asignar
     FROM tickets"
)->fetch();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Atalanta | Panel Jefe</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<style><?php include '../dashboard_styles.css.php'; ?></style>
</head>
<body>

<?php include '../topbar.php'; ?>

<div class="container">
    <div class="page-title">Panel de <span>Coordinación</span></div>
    <div class="page-sub">Asigna tickets a trabajadores y supervisa el estado global</div>

    <!-- Stats -->
    <div class="stats-row" style="grid-template-columns:repeat(5,1fr);">
        <div class="stat-box"><div class="num"><?= $stats['total'] ?? 0 ?></div><div class="lbl">Total</div></div>
        <div class="stat-box"><div class="num" style="color:#f97316"><?= $stats['abiertos'] ?? 0 ?></div><div class="lbl">Abiertos</div></div>
        <div class="stat-box"><div class="num" style="color:#60a5fa"><?= $stats['en_progreso'] ?? 0 ?></div><div class="lbl">En progreso</div></div>
        <div class="stat-box"><div class="num" style="color:#4ade80"><?= $stats['resueltos'] ?? 0 ?></div><div class="lbl">Resueltos</div></div>
        <div class="stat-box"><div class="num" style="color:#f87171"><?= $stats['sin_asignar'] ?? 0 ?></div><div class="lbl">Sin asignar</div></div>
    </div>

    <!-- Filtros rápidos -->
    <div style="display:flex;gap:.7rem;margin-bottom:1.2rem;flex-wrap:wrap;">
        <button class="btn-filter active" onclick="filtrar('todos',this)">Todos</button>
        <button class="btn-filter" onclick="filtrar('abierto',this)">Abiertos</button>
        <button class="btn-filter" onclick="filtrar('en_progreso',this)">En progreso</button>
        <button class="btn-filter" onclick="filtrar('sin_asignar',this)">Sin asignar</button>
        <button class="btn-filter" onclick="filtrar('critica',this)">🔴 Críticos</button>
    </div>

    <!-- Tabla tickets -->
    <div class="card">
        <div class="card-header">🗂️ Gestión Global de Tickets</div>
        <table id="tabla-tickets">
            <thead>
                <tr>
                    <th>#</th><th>Título</th><th>Cliente</th>
                    <th>Prioridad</th><th>Estado</th>
                    <th>Asignar a</th><th>Fecha</th><th>Acción</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tickets as $t): ?>
                <tr data-estado="<?= $t['estado'] ?>" data-prioridad="<?= $t['prioridad'] ?>" data-asignado="<?= $t['trabajador_id'] ? '1' : '0' ?>">
                    <td><?= $t['id'] ?></td>
                    <td>
                        <?= htmlspecialchars($t['titulo']) ?>
                        <?php if ($t['categoria']): ?>
                            <div style="font-size:.72rem;color:#475569;"><?= htmlspecialchars($t['categoria']) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($t['cliente_nombre'].' '.$t['cliente_apellidos']) ?></td>
                    <td><span class="badge badge-prior-<?= $t['prioridad'] ?>"><?= strtoupper($t['prioridad']) ?></span></td>
                    <td>
                        <select class="select-estado" onchange="cambiarEstado(<?= $t['id'] ?>, this.value)">
                            <?php foreach (['abierto','en_progreso','resuelto','cerrado'] as $e): ?>
                                <option value="<?= $e ?>" <?= $t['estado'] === $e ? 'selected' : '' ?>><?= ucfirst(str_replace('_',' ',$e)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select class="select-estado" onchange="asignarTicket(<?= $t['id'] ?>, this.value)">
                            <option value="0" <?= !$t['trabajador_id'] ? 'selected' : '' ?>>— Sin asignar —</option>
                            <?php foreach ($trabajadores as $w): ?>
                                <option value="<?= $w['id'] ?>" <?= $t['trabajador_id'] == $w['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($w['nombre'].' '.$w['apellidos']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><?= date('d/m/Y', strtotime($t['created_at'])) ?></td>
                    <td>
                        <button class="btn-sm" onclick="verComentarios(<?= $t['id'] ?>, '<?= htmlspecialchars(addslashes($t['titulo'])) ?>')">Ver</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal: Comentarios -->
<div class="modal" id="modal-comentarios">
    <div class="modal-box modal-lg">
        <div class="modal-header">
            <h3 id="modal-ticket-titulo">Ticket</h3>
            <button class="modal-close" onclick="cerrarModal('modal-comentarios')">✕</button>
        </div>
        <div id="lista-comentarios" style="max-height:350px;overflow-y:auto;margin-bottom:1rem;"></div>
        <div class="form-group">
            <label>Añadir comentario</label>
            <textarea id="nuevo-comentario" rows="3" placeholder="Escribe tu comentario..."></textarea>
        </div>
        <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:1rem;">
            <input type="checkbox" id="com-interno" style="accent-color:#db0936;">
            <label for="com-interno" style="font-size:.82rem;color:#94a3b8;">Nota interna</label>
        </div>
        <div class="modal-footer">
            <button class="btn-ghost" onclick="cerrarModal('modal-comentarios')">Cerrar</button>
            <button class="btn-primary" onclick="enviarComentario()">Enviar</button>
        </div>
    </div>
</div>

<div class="toast" id="toast"></div>

<script>
let ticketActivo = null;

async function asignarTicket(id, trabajadorId) {
    const fd = new FormData();
    fd.append('action',        'asignar_ticket');
    fd.append('ticket_id',     id);
    fd.append('trabajador_id', trabajadorId);
    const res  = await fetch('jefe.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
}

async function cambiarEstado(id, estado) {
    const fd = new FormData();
    fd.append('action',    'cambiar_estado');
    fd.append('ticket_id', id);
    fd.append('estado',    estado);
    const res  = await fetch('jefe.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
}

async function verComentarios(id, titulo) {
    ticketActivo = id;
    document.getElementById('modal-ticket-titulo').textContent = 'Ticket #' + id + ' — ' + titulo;
    await cargarComentarios();
    abrirModal('modal-comentarios');
}

async function cargarComentarios() {
    const res  = await fetch('../api_comentarios.php?ticket_id=' + ticketActivo);
    const data = await res.json();
    const lista = document.getElementById('lista-comentarios');
    if (!data.length) { lista.innerHTML = '<p style="color:#94a3b8;text-align:center;">Sin comentarios.</p>'; return; }
    lista.innerHTML = data.map(c => `
        <div class="comentario ${c.interno ? 'interno' : ''}">
            <div class="com-author">${c.autor} <span class="com-date">${c.fecha}</span>
                ${c.interno ? '<span style="color:#f97316;font-size:.7rem;margin-left:.4rem;">[INTERNO]</span>' : ''}
            </div>
            <div class="com-msg">${c.mensaje}</div>
        </div>`).join('');
    lista.scrollTop = lista.scrollHeight;
}

async function enviarComentario() {
    const msg     = document.getElementById('nuevo-comentario').value.trim();
    const interno = document.getElementById('com-interno').checked ? 1 : 0;
    if (!msg) { toast('Escribe algo.', 'err'); return; }
    const fd = new FormData();
    fd.append('ticket_id', ticketActivo);
    fd.append('mensaje',   msg);
    fd.append('interno',   interno);
    const res  = await fetch('../api_comentarios.php', { method:'POST', body: fd });
    const data = await res.json();
    toast(data.message, data.success ? 'ok' : 'err');
    if (data.success) { document.getElementById('nuevo-comentario').value = ''; document.getElementById('com-interno').checked = false; cargarComentarios(); }
}

// Filtros de tabla
function filtrar(tipo, btn) {
    document.querySelectorAll('.btn-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('#tabla-tickets tbody tr').forEach(tr => {
        let show = true;
        if      (tipo === 'abierto')      show = tr.dataset.estado    === 'abierto';
        else if (tipo === 'en_progreso')  show = tr.dataset.estado    === 'en_progreso';
        else if (tipo === 'sin_asignar')  show = tr.dataset.asignado  === '0' && tr.dataset.estado !== 'cerrado';
        else if (tipo === 'critica')      show = tr.dataset.prioridad === 'critica';
        tr.style.display = show ? '' : 'none';
    });
}

function abrirModal(id)  { document.getElementById(id).classList.add('show'); }
function cerrarModal(id) { document.getElementById(id).classList.remove('show'); }
function toast(msg, type) {
    const t = document.getElementById('toast');
    t.textContent = msg; t.className = 'toast show ' + type;
    setTimeout(() => t.className = 'toast', 3500);
}
</script>
</body>
</html>
