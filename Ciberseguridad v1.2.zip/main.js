/* ═══════════════════════════════════════════
   HERO — fade + parallax on scroll
═══════════════════════════════════════════ */
(function() {
  var hero      = document.getElementById('hero');
  if (!hero) return;
  var content   = hero.querySelector('.hero-content');
  var right     = hero.querySelector('.hero-right');
  var scrollCue = hero.querySelector('.hero-scroll');
  var orbs      = hero.querySelectorAll('.orb');
  var grid      = hero.querySelector('.hero-grid');

  function onScroll() {
    var sy = window.pageYOffset;
    var hh = hero.offsetHeight;
    var p  = Math.min(sy / (hh * 0.4), 1);
    var fade = Math.max(0, 1 - p * 1.6);
    var moveY = p * -48;

    if (content) {
      content.style.opacity   = fade;
      content.style.transform = 'translateY(' + moveY + 'px)';
    }
    if (right) {
      right.style.opacity   = fade;
      right.style.transform = 'translate(0, calc(-50% + ' + (moveY * 0.6) + 'px))';
    }
    if (scrollCue) {
      scrollCue.style.opacity = Math.max(0, 1 - p * 4);
    }
    orbs.forEach(function(o) {
      o.style.opacity = Math.max(0, 1 - p * 2.2);
    });
    if (grid) {
      grid.style.opacity = Math.max(0.15, 1 - p * 1.3);
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
})();

/* ═══════════════════════════════════════════
   SCROLL REVEAL
═══════════════════════════════════════════ */
(function() {
  var els = document.querySelectorAll('.reveal');
  if (!els.length) return;

  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var siblings = Array.prototype.slice.call(
          entry.target.parentElement.querySelectorAll('.reveal:not(.visible)')
        );
        var idx = siblings.indexOf(entry.target);
        setTimeout(function() {
          entry.target.classList.add('visible');
        }, idx * 65);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -20px 0px' });

  els.forEach(function(el) { observer.observe(el); });
})();

/* ═══════════════════════════════════════════
   CAROUSEL — pause / resume
═══════════════════════════════════════════ */
(function() {
  var wrapper = document.getElementById('carouselWrapper');
  var btn     = document.getElementById('carouselBtn');
  var status  = document.getElementById('carouselStatus');
  var paused  = false;

  if (!btn || !wrapper) return;

  btn.addEventListener('click', function() {
    paused = !paused;
    if (paused) {
      wrapper.classList.add('carousel-paused');
      btn.textContent    = '▶';
      status.textContent = 'Pausado — Click para reanudar';
    } else {
      wrapper.classList.remove('carousel-paused');
      btn.textContent    = '⏸';
      status.textContent = 'Hover para pausar · Click para detener';
    }
  });
})();

/* ═══════════════════════════════════════════
   SMOOTH SCROLL — all anchor links
═══════════════════════════════════════════ */
(function() {
  document.querySelectorAll('a[href^="#"]').forEach(function(a) {
    a.addEventListener('click', function(e) {
      var id = a.getAttribute('href');
      if (id === '#') return;
      var target = document.querySelector(id);
      if (target) {
        e.preventDefault();
        var navHeight = 68;
        var top = target.getBoundingClientRect().top + window.pageYOffset - navHeight;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    });
  });
})();

/* ═══════════════════════════════════════════
   COUNTER ANIMATION — metrics
═══════════════════════════════════════════ */
(function() {
  var counters = document.querySelectorAll('.metric-num');
  if (!counters.length) return;
  var done = false;

  // Store original values BEFORE any DOM manipulation
  var targets = [];
  counters.forEach(function(el) {
    var unit     = el.querySelector('.unit');
    var unitText = unit ? unit.textContent : '';
    var rawText  = el.textContent.replace(unitText, '').trim();
    var isFloat  = rawText.indexOf(',') !== -1 || rawText.indexOf('.') !== -1;
    var target   = parseFloat(rawText.replace(',', '.'));
    targets.push({ el: el, unitText: unitText, isFloat: isFloat, target: target });
  });

  var obs = new IntersectionObserver(function(entries) {
    if (done) return;
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        done = true;
        targets.forEach(function(item) {
          if (isNaN(item.target)) return;

          var start     = 0;
          var duration  = 1600;
          var startTime = null;

          function step(ts) {
            if (!startTime) startTime = ts;
            var progress = Math.min((ts - startTime) / duration, 1);
            var ease     = 1 - Math.pow(1 - progress, 3);
            var current  = start + (item.target - start) * ease;
            var display  = item.isFloat
              ? current.toFixed(2).replace('.', ',')
              : Math.round(current).toString();

            if (item.unitText) {
              item.el.innerHTML = display + '<span class="unit">' + item.unitText + '</span>';
            } else {
              item.el.textContent = display;
            }
            if (progress < 1) requestAnimationFrame(step);
          }
          requestAnimationFrame(step);
        });
        obs.disconnect();
      }
    });
  }, { threshold: 0.3 });

  var firstMetric = document.querySelector('.metric-box');
  if (firstMetric) obs.observe(firstMetric);
})();

/* ═══════════════════════════════════════════
   FORM — basic validation + feedback
═══════════════════════════════════════════ */
(function() {
  var btn = document.querySelector('.form-submit');
  if (!btn) return;

  btn.addEventListener('click', function() {
    var email    = document.querySelector('input[type="email"]');
    var checkbox = document.querySelector('.form-check input[type="checkbox"]');

    if (email && !email.value.trim()) {
      email.focus();
      email.style.borderColor = 'rgba(220,6,48,0.8)';
      setTimeout(function() { email.style.borderColor = ''; }, 2000);
      return;
    }
    if (checkbox && !checkbox.checked) {
      checkbox.parentElement.style.outline = '1px solid rgba(220,6,48,0.6)';
      checkbox.parentElement.style.borderRadius = '4px';
      setTimeout(function() { checkbox.parentElement.style.outline = ''; }, 2000);
      return;
    }

    var original = btn.innerHTML;
    btn.innerHTML = '✓ Solicitud enviada correctamente';
    btn.style.background = '#16a34a';
    btn.disabled = true;
    setTimeout(function() {
      btn.innerHTML = original;
      btn.style.background = '';
      btn.disabled = false;
    }, 3500);
  });
})();

/* ═══════════════════════════════════════════
   NAV — highlight active section on scroll
═══════════════════════════════════════════ */
(function() {
  var sections = document.querySelectorAll('section[id]');
  var navLinks = document.querySelectorAll('.nav-links a');
  if (!navLinks.length || !sections.length) return;

  function onScroll() {
    var scrollY = window.pageYOffset + 120;
    sections.forEach(function(sec) {
      if (scrollY >= sec.offsetTop && scrollY < sec.offsetTop + sec.offsetHeight) {
        navLinks.forEach(function(a) {
          a.classList.remove('active');
          if (a.getAttribute('href') === '#' + sec.id) {
            a.classList.add('active');
          }
        });
      }
    });
  }

  window.addEventListener('scroll', onScroll, { passive: true });
})();
